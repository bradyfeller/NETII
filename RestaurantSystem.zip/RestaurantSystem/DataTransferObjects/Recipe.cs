﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataTransferObjects
{
    public class Recipe
    {
        public int RecipeID { get; set; }
        public int MenuItemID { get; set; }
        public string Name { get; set; }
        public string Instructions { get; set; }
        public bool Active { get; set; }
    }
}
