﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataTransferObjects
{
    public class Ingredient
    {
        public int MenuItemID { get; set; }
        public int FoodItemID { get; set; }
        public int Quantity { get; set; }
        public string Unit { get; set; }
        public bool Active { get; set; }
    }
}
