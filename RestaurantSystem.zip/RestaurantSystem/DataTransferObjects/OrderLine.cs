﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataTransferObjects
{
    public class OrderLine
    {
        public int OrderID { get; set; }
        public int MenuItemID { get; set; }
        public bool Active { get; set; }
    }
}
