﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataTransferObjects
{
    public class Equipment
    {
        /* [EquipmentID],[Name],[Description],[StatusID],
		   [EquipmentModelID], [InspectionListID],
		   [PrepListID],[Active] */
        public int EquipmentID { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public string StatusID { get; set; }
        public int EquipmentModelID { get; set; }
        public int? InspectionListID { get; set; }
        public int? PrepListID { get; set; }
        public bool Active { get; set; }
    }
}
