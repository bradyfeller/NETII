﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataTransferObjects
{
    public class Order
    {
        public int OrderID { get; set; }
        public string EmployeeID { get; set; }
        public DateTime OrderPlaced { get; set; }
        public string OrderStatusID { get; set; }
        public bool Active { get; set; }
    }
}
