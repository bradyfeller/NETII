﻿using DataTransferObjects;
using LogicLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace RestaurantSystem
{
    /// <summary>
    /// Interaction logic for frmOrderStatus.xaml
    /// </summary>
    public partial class frmOrderStatus : Window
    {
        private OrderManager _orderManager;
        private Order _order;
        private List<OrderStatus> _orderStatusList = null;


        public frmOrderStatus(OrderManager orMgr, Order orDetail)
        {
            _orderManager = orMgr;
            _order = orDetail;
            InitializeComponent();
        }

        private void populateControls()
        {
            this.cboStatus.ItemsSource = _orderManager.RetrieveOrderStatusList();
            foreach (var i in cboStatus.Items)
            {
                if (((OrderStatus)i).ToString() == _order.OrderStatusID)
                {
                    cboStatus.SelectedItem = i;
                    break;
                }
            }
        }

        public frmOrderStatus()
        {
            InitializeComponent();
        }

        private void btnSaveEdit_Click(object sender, RoutedEventArgs e)
        {
            var orderStatusID = cboStatus.Text;
            try
            {
                _order = _orderManager.UpdateOrder(_order, orderStatusID);
                this.DialogResult = true;
            }
            catch (Exception ex)
            {
                var message = ex.Message + "\n\n" + ex.InnerException.Message;

                MessageBox.Show("Update Failed!" + message);
                return;
            }
        }

        private void btnCancel_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = false;
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            try
            {
                _orderStatusList = _orderManager.RetrieveOrderStatusList();

                this.cboStatus.ItemsSource = _orderStatusList;
            }
            catch (Exception)
            {
                MessageBox.Show("One or more option lists were not found!");
            }
        }
    }
}
