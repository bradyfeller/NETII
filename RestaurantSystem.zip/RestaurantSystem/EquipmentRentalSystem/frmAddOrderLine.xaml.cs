﻿using DataTransferObjects;
using LogicLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace RestaurantSystem
{
    /// <summary>
    /// Interaction logic for frmAddOrderLine.xaml
    /// </summary>
    public partial class frmAddOrderLine : Window
    {
        private OrderManager _orderManager;
        private DetailMode _mode;

        public frmAddOrderLine(OrderManager orMgr)
        {
            _orderManager = orMgr;
            _mode = DetailMode.Add;

            InitializeComponent();
        }

        public frmAddOrderLine()
        {
            InitializeComponent();
        }

        private void setupAddMode()
        {
            setInputs(readOnly: false);
        }

        private void setInputs(bool readOnly = true)
        {
            this.txtOrderID.IsReadOnly = readOnly;
            this.txtMenuItemID.IsReadOnly = readOnly;
        }

        private void btnSave_Click(object sender, RoutedEventArgs e)
        {
            var orderID = txtOrderID.Text;
            var menuItemID = txtMenuItemID.Text;

            var orderLine = new OrderLine();

            switch (_mode)
            {
                case DetailMode.Add:
                    if (captureOrderLine(orderLine) == false)
                    {
                        return;
                    }
                    try
                    {
                        if (_orderManager.SaveNewOrderLine(orderLine))
                        {
                            this.DialogResult = true;
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                    break;
                case DetailMode.View:
                    break;
                default:
                    break;
            }
        }

        private void btnCancel_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = false;
        }

        private bool captureOrderLine(OrderLine orderLine)
        {

            if (this.txtOrderID.Text == "")
            {
                MessageBox.Show("You must enter a name.");
                return false;
            }
            else
            {
                orderLine.OrderID = Int32.Parse(txtOrderID.Text);
            }
            if (this.txtMenuItemID.Text == "")
            {
                MessageBox.Show("You must enter a description.");
                return false;
            }
            else
            {
                orderLine.MenuItemID = Int32.Parse(txtMenuItemID.Text);
            }
            return true;
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            switch (_mode)
            {
                case DetailMode.Add:
                    setupAddMode();
                    break;
                default:
                    break;
            }
        }
    }
}
