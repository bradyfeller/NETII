﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using DataTransferObjects;
using LogicLayer;

namespace RestaurantSystem
{
    /// <summary>
    /// Interaction logic for frmFoodItem.xaml
    /// </summary>
    public partial class frmFoodItem : Window
    {
        private FoodItemManager _foodItemManager;
        private FoodItemDetail _foodItemDetail;
        private FoodItem _foodItem;
        private DetailMode _mode;

        public frmFoodItem(FoodItemManager fiMgr, FoodItemDetail fiDetail, DetailMode mode)
        {
            _foodItemManager = fiMgr;
            _foodItemDetail = fiDetail;
            _mode = mode;

            InitializeComponent();
        }

        public frmFoodItem(FoodItemManager fiMgr)
        {
            _foodItemManager = fiMgr;
            _mode = DetailMode.Add;

            InitializeComponent();
        }

        private void populateControls()
        {
            this.txtFoodItemID.Text = _foodItemDetail.FoodItem.FoodItemID.ToString();
            this.txtFoodItemName.Text = _foodItemDetail.FoodItem.Name;
            this.txtFoodItemDescription.Text = _foodItemDetail.FoodItem.Description;
        }

        private void setupViewMode()
        {
            this.btnSaveEdit.Content = "Edit";
            populateControls();
            setInputs(readOnly: true);
        }
        private void setupEditMode()
        {
            populateControls();
            setInputs(readOnly: false);
        }
        private void setupAddMode()
        {
            setInputs(readOnly: false);
        }

        private void setInputs(bool readOnly = true)
        {
            this.txtFoodItemID.IsReadOnly = true;
            this.txtFoodItemName.IsReadOnly = readOnly;
            this.txtFoodItemDescription.IsReadOnly = readOnly;
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            switch (_mode)
            {
                case DetailMode.View:
                    setupViewMode();
                    break;
                case DetailMode.Edit:
                    setupEditMode();
                    break;
                case DetailMode.Add:
                    setupAddMode();
                    break;
                default:
                    break;
            }
        }

        private void btnSaveEdit_Click(object sender, RoutedEventArgs e)
        {
            var newName = txtFoodItemName.Text;
            var newDescription = txtFoodItemDescription.Text;

            if (_mode == DetailMode.View)
            {
                _mode = DetailMode.Edit;
                setupEditMode();
                this.btnSaveEdit.Content = "Save";
                return;
            }

            if (_mode == DetailMode.Edit)
            {
                try
                {
                    _foodItem = _foodItemManager.UpdateFoodItem(_foodItemDetail.FoodItem, newName, newDescription);
                    this.DialogResult = true;
                }
                catch (Exception ex)
                {
                    var message = ex.Message + "\n\n" + ex.InnerException.Message;

                    MessageBox.Show("Update Failed!");
                    return;
                }
            }

            var foodItem = new FoodItem();

            switch (_mode)
            {
                case DetailMode.Add:
                    if (captureFoodItem(foodItem) == false)
                    {
                        return;
                    }
                    try
                    {
                        if (_foodItemManager.SaveNewFoodItem(foodItem))
                        {
                            this.DialogResult = true;
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                    break;
                case DetailMode.View:
                    break;
                default:
                    break;
            }
        }

        private bool captureFoodItem(FoodItem foodItem)
        {
            
            if (this.txtFoodItemName.Text == "")
            {
                MessageBox.Show("You must enter a name.");
                return false;
            }
            else
            {
                foodItem.Name = txtFoodItemName.Text;
            }
            if (this.txtFoodItemDescription.Text == "")
            {
                MessageBox.Show("You must enter a description.");
                return false;
            }
            else
            {
                foodItem.Description = txtFoodItemDescription.Text;
            }
            return true;
        }

        private void btnCancel_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = false;
        }
    }
}
