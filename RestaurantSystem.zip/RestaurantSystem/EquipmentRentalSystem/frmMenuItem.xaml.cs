﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using DataTransferObjects;
using LogicLayer;

namespace RestaurantSystem
{
    /// <summary>
    /// Interaction logic for frmMenuItem.xaml
    /// </summary>
    public partial class frmMenuItem : Window
    {
        private MenuItemManager _menuItemManager;
        private MenuItemDetail _menuItemDetail;
        private DataTransferObjects.MenuItem _menuItem;
        private DetailMode _mode;

        public frmMenuItem(MenuItemManager miMgr, MenuItemDetail miDetail, DetailMode mode)
        {
            _menuItemManager = miMgr;
            _menuItemDetail = miDetail;
            _mode = mode;

            InitializeComponent();
        }

        public frmMenuItem(MenuItemManager miMgr)
        {
            _menuItemManager = miMgr;
            _mode = DetailMode.Add;

            InitializeComponent();
        }

        private void populateControls()
        {
            this.txtMenuItemID.Text = _menuItemDetail.MenuItem.MenuItemID.ToString();
            this.txtMenuItemName.Text = _menuItemDetail.MenuItem.Name;
            this.txtMenuItemDescription.Text = _menuItemDetail.MenuItem.Description;
        }

        private void setupViewMode()
        {
            this.btnSaveEdit.Content = "Edit";
            populateControls();
            setInputs(readOnly: true);
        }
        private void setupEditMode()
        {
            populateControls();
            setInputs(readOnly: false);
        }
        private void setupAddMode()
        {
            setInputs(readOnly: false);
        }

        private void setInputs(bool readOnly = true)
        {
            this.txtMenuItemID.IsReadOnly = true;
            this.txtMenuItemName.IsReadOnly = readOnly;
            this.txtMenuItemDescription.IsReadOnly = readOnly;
        }

        private void btnSaveEdit_Click(object sender, RoutedEventArgs e)
        {
            var newName = txtMenuItemName.Text;
            var newDescription = txtMenuItemDescription.Text;

            if (_mode == DetailMode.View)
            {
                _mode = DetailMode.Edit;
                setupEditMode();
                this.btnSaveEdit.Content = "Save";
                return;
            }

            if (_mode == DetailMode.Edit)
            {
                try
                {
                    _menuItem = _menuItemManager.UpdateMenuItem(_menuItemDetail.MenuItem, newName, newDescription);
                    this.DialogResult = true;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Update Failed!");
                    return;
                }
            }

            var menuItem = new DataTransferObjects.MenuItem();

            switch (_mode)
            {
                case DetailMode.Add:
                    if (captureMenuItem(menuItem) == false)
                    {
                        return;
                    }
                    try
                    {
                        if (_menuItemManager.SaveNewMenuItem(menuItem))
                        {
                            this.DialogResult = true;
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                    break;
                case DetailMode.View:
                    break;
                default:
                    break;
            }
        }

        private bool captureMenuItem(DataTransferObjects.MenuItem menuItem)
        {

            if (this.txtMenuItemName.Text == "")
            {
                MessageBox.Show("You must enter a name.");
                return false;
            }
            else
            {
                menuItem.Name = txtMenuItemName.Text;
            }
            if (this.txtMenuItemDescription.Text == "")
            {
                MessageBox.Show("You must enter a description.");
                return false;
            }
            else
            {
                menuItem.Description = txtMenuItemDescription.Text;
            }
            return true;
        }

        private void btnCancel_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = false;
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            switch (_mode)
            {
                case DetailMode.View:
                    setupViewMode();
                    break;
                case DetailMode.Edit:
                    setupEditMode();
                    break;
                case DetailMode.Add:
                    setupAddMode();
                    break;
                default:
                    break;
            }
        }
    }
}
