﻿using DataTransferObjects;
using LogicLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace RestaurantSystem
{
    /// <summary>
    /// Interaction logic for frmIngredient.xaml
    /// </summary>
    public partial class frmIngredient : Window
    {
        private RecipeManager _recipeManager = new RecipeManager();
        private int _menuItemID;
        private List<Ingredient> _ingredientList;

        public frmIngredient(RecipeManager recipeManager, int menuItemID)
        {
            _recipeManager = recipeManager;
            _menuItemID = menuItemID;
            InitializeComponent();
        }

        public frmIngredient()
        {
            InitializeComponent();
        }

        private void refreshIngredientList(int menuItemID)
        {
            try
            {
                _ingredientList = _recipeManager.RetrieveIngredientList(_menuItemID);
            }
            catch (Exception ex)
            {
                var message = ex.Message + "\n\n" + ex.InnerException.Message;
                MessageBox.Show(message, "Data Retrieval Error!",
                    MessageBoxButton.OK, MessageBoxImage.Exclamation);
            }
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            refreshIngredientList(100000);
        }

        private void tabIngredient_GotFocus(object sender, RoutedEventArgs e)
        {
            dgIngredient.ItemsSource = _ingredientList;
        }

        private void btnAddIngredient_Click(object sender, RoutedEventArgs e)
        {
            var frmAddIngredient = new frmAddIngredient(_recipeManager);
            var result = frmAddIngredient.ShowDialog();
            if (result == true)
            {
                dgIngredient.ItemsSource = _ingredientList;
                refreshIngredientList(1);
            }
        }

        private void btnDeactivateIngredient_Click(object sender, RoutedEventArgs e)
        {
            if (dgIngredient.SelectedItems.Count == 0)
            {
                MessageBox.Show("You need to select something!");
                return;
            }
            else
            {
                var result = MessageBox.Show("Deactivate " +
                    ((Ingredient)(dgIngredient.SelectedItem)).MenuItemID +
                    "? Are you sure?", "Deactivate Order",
                    MessageBoxButton.OKCancel, MessageBoxImage.Warning);

                if (result == MessageBoxResult.OK)
                {
                    _recipeManager.DeactivateIngredient((Ingredient)dgIngredient.SelectedItem);
                    refreshIngredientList(100001);
                }
                else
                {
                    return;
                }
            }
        }
    }
}
