﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using DataTransferObjects;
using LogicLayer;

namespace RestaurantSystem
{
    /// <summary>
    /// Interaction logic for frmEquipmentDetail.xaml
    /// </summary>
    public partial class frmEquipmentDetail : Window
    {
        private EquipmentManager _equipmentManager;
        private EquipmentDetail _equipmentDetail;
        private DetailMode _mode;


        public frmEquipmentDetail(EquipmentManager eqMgr, EquipmentDetail eqDetail, DetailMode mode)
        {
            _equipmentManager = eqMgr;
            _equipmentDetail = eqDetail;
            _mode = mode;

            InitializeComponent();
        }

        public frmEquipmentDetail(EquipmentManager eqMgr) // no detail object = add mode
        {
            _equipmentManager = eqMgr;
            _equipmentDetail = null;
            _mode = DetailMode.Add;

            InitializeComponent();
        }


        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            try
            {
                this.cboStatus.ItemsSource = _equipmentManager.RetrieveStatusList();
                foreach (var i in cboStatus.Items)
                {
                    if (((Status)i).StatusID == _equipmentDetail.Equipment.StatusID)
                    {
                        cboStatus.SelectedItem = i;
                        break;
                    }
                } 
            }
            catch(Exception ex)
            {
                MessageBox.Show("Equipment Status List Access Problem\n\n" + ex.InnerException.Message);
            }

            switch (_mode)
            {
                case DetailMode.View:
                    setupViewMode();
                    break;
                case DetailMode.Edit:
                    setupEditMode();
                    break;
                case DetailMode.Add:
                    setupAddMode();
                    break;
                default:
                    break;
            }
        }

        private void populateControls()
        {
            this.txtEquipmentID.Text = _equipmentDetail.Equipment.EquipmentID.ToString();
            this.txtName.Text = _equipmentDetail.Equipment.Name;
            this.txtDescription.Text = _equipmentDetail.Equipment.Description;
            // this.txtStatus.Text = _equipmentDetail.Equipment.StatusID;
            this.txtModel.Text = _equipmentDetail.EquipmentModel.Name;
            this.txtModelDescription.Text = _equipmentDetail.EquipmentModel.Description;
            this.txtInspectionList.Text = _equipmentDetail.InspectionList.Name;
            this.txtInspectionListDescription.Text = _equipmentDetail.InspectionList.Description;
            this.txtPrepList.Text = _equipmentDetail.PrepList.Name;
            this.txtPrepListDescription.Text = _equipmentDetail.PrepList.Description;
        }

        private void setupViewMode()
        {
            this.btnSaveEdit.Content = "Edit";
            populateControls();
            setInputs(readOnly: true);
        }
        private void setupEditMode()
        {
            populateControls();
            setInputs(readOnly: false);
        }
        private void setupAddMode()
        {
            setInputs(readOnly: false);
        }

        private void setInputs(bool readOnly = true)
        {
            this.txtEquipmentID.IsReadOnly = true; // this doesn't change - not user editable
            this.txtName.IsReadOnly = readOnly;
            this.txtDescription.IsReadOnly = readOnly;
            this.cboStatus.IsEnabled = !readOnly;
            this.txtModel.IsReadOnly = readOnly;
            this.txtModelDescription.IsReadOnly = readOnly;
            this.txtInspectionList.IsReadOnly = readOnly;
            this.txtInspectionListDescription.IsReadOnly = readOnly;
            this.txtPrepList.IsReadOnly = readOnly;
            this.txtPrepListDescription.IsReadOnly = readOnly;
        }

        private void btnCancel_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = false;
        }

        private void btnSaveEdit_Click(object sender, RoutedEventArgs e)
        {
            if(_mode == DetailMode.View) // if in view mode, switch to edit mode
            {
                setupEditMode();
                this.btnSaveEdit.Content = "Save";
                return;
            }
                // need logic to actually save the record
        }
    }
}
