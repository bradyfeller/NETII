﻿using DataTransferObjects;
using LogicLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace RestaurantSystem
{
    /// <summary>
    /// Interaction logic for frmAddOrder.xaml
    /// </summary>
    public partial class frmAddOrder : Window
    {
        private OrderManager _orderManager;
        private DetailMode _mode;

        public frmAddOrder(OrderManager orMgr)
        {
            _orderManager = orMgr;
            _mode = DetailMode.Add;

            InitializeComponent();
        }

        public frmAddOrder()
        {
            InitializeComponent();
        }

        private void setInputs(bool readOnly = true)
        {
            this.txtOrderID.IsReadOnly = true;
            this.txtEmployeeID.IsReadOnly = readOnly;
            this.txtDateTime.IsReadOnly = readOnly;
        }

        private void setupAddMode()
        {
            setInputs(readOnly: false);
        }

        private void btnSave_Click(object sender, RoutedEventArgs e)
        {
            var employeeID = txtEmployeeID.Text;
            var dateTime = txtDateTime.Text;

            var order = new Order();

            switch (_mode)
            {
                case DetailMode.Add:
                    if (captureOrder(order) == false)
                    {
                        return;
                    }
                    try
                    {
                        if (_orderManager.SaveNewOrder(order))
                        {
                            this.DialogResult = true;
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                    break;
                case DetailMode.View:
                    break;
                default:
                    break;
            }
        }

        private void btnCancel_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = false;
        }

        private bool captureOrder(Order order)
        {

            if (this.txtEmployeeID.Text == "")
            {
                MessageBox.Show("You must enter a name.");
                return false;
            }
            else
            {
                order.EmployeeID = txtEmployeeID.Text;
                order.OrderPlaced = Convert.ToDateTime(txtDateTime.Text);
            }
            return true;
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            switch (_mode)
            {
                case DetailMode.Add:
                    setupAddMode();
                    break;
                default:
                    break;
            }
        }

        
    }
}
