﻿using DataTransferObjects;
using LogicLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace RestaurantSystem
{
    /// <summary>
    /// Interaction logic for frmOrderLine.xaml
    /// </summary>
    public partial class frmOrderLine : Window
    {
        private List<OrderLine> _orderLineList;
        private int _orderID;
        private OrderManager _orderManager;

        public frmOrderLine(OrderManager orderManager, int orderID)
        {
            _orderManager = orderManager;
            _orderID = orderID;
            InitializeComponent();
        }

        private void refreshOrderLineList(int orderID)
        {
            try
            {
                _orderLineList = _orderManager.RetrieveOrderLineList(_orderID);
            }
            catch (Exception ex)
            {
                var message = ex.Message + "\n\n" + ex.InnerException.Message;
                MessageBox.Show(message, "Data Retrieval Error!",
                    MessageBoxButton.OK, MessageBoxImage.Exclamation);
            }
        }
        
        private void dgOrderLine_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {

        }

        private void btnAddOrderLine_Click(object sender, RoutedEventArgs e)
        {
            var frmAddOrderLine = new frmAddOrderLine(_orderManager);
            var result = frmAddOrderLine.ShowDialog();
            if (result == true)
            {
                dgOrderLine.ItemsSource = _orderLineList;
                refreshOrderLineList(1);
            }
        }

        private void btnDeactivateOrderLine_Click(object sender, RoutedEventArgs e)
        {
            if (dgOrderLine.SelectedItems.Count == 0)
            {
                MessageBox.Show("You need to select something!");
                return;
            }
            else
            {
                var result = MessageBox.Show("Deactivate " +
                    ((OrderLine)(dgOrderLine.SelectedItem)).OrderID +
                    "? Are you sure?", "Deactivate Order",
                    MessageBoxButton.OKCancel, MessageBoxImage.Warning);

                if (result == MessageBoxResult.OK)
                {
                    _orderManager.DeactivateOrderLine((OrderLine)dgOrderLine.SelectedItem);
                    refreshOrderLineList(100001);
                }
                else
                {
                    return;
                }
            }
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            refreshOrderLineList(100001);
        }

        private void tabOrderLine_GotFocus(object sender, RoutedEventArgs e)
        {
            dgOrderLine.ItemsSource = _orderLineList;
        }
    }
}
