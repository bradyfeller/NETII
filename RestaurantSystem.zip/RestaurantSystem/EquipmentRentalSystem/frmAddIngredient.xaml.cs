﻿using DataTransferObjects;
using LogicLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace RestaurantSystem
{
    /// <summary>
    /// Interaction logic for frmAddIngredient.xaml
    /// </summary>
    public partial class frmAddIngredient : Window
    {
        private RecipeManager _recipeManager;
        private DetailMode _mode;

        public frmAddIngredient(RecipeManager reMgr)
        {
            _recipeManager = reMgr;
            _mode = DetailMode.Add;

            InitializeComponent();
        }

        public frmAddIngredient()
        {
            InitializeComponent();
        }

        private void setupAddMode()
        {
            setInputs(readOnly: false);
        }

        private void setInputs(bool readOnly = true)
        {
            this.txtMenuItemID.IsReadOnly = readOnly;
            this.txtFoodItemID.IsReadOnly = readOnly;
            this.txtQuantity.IsReadOnly = readOnly;
            this.txtUnit.IsReadOnly = readOnly;
        }

        private void btnSave_Click(object sender, RoutedEventArgs e)
        {
            var menuItemID = txtMenuItemID.Text;
            var foodItemID = txtFoodItemID.Text;
            var quantity = txtQuantity.Text;
            var unit = txtUnit.Text;

            var ingredient = new Ingredient();

            switch (_mode)
            {
                case DetailMode.Add:
                    // validate inputs and build the equipment
                    if (captureIngredient(ingredient) == false)
                    {
                        return;
                    }
                    // pass it to a manager class method
                    try
                    {
                        if (_recipeManager.SaveNewIngredient(ingredient))
                        {
                            this.DialogResult = true;
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                    break;
                case DetailMode.View:
                    break;
                default:
                    break;
            }
        }

        private void btnCancel_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = false;
        }

        private bool captureIngredient(Ingredient ingredient)
        {

            if (this.txtMenuItemID.Text == "")
            {
                MessageBox.Show("You must enter a menu item ID.");
                return false;
            }
            else
            {
                ingredient.MenuItemID = Int32.Parse(txtMenuItemID.Text);
            }
            if (this.txtFoodItemID.Text == "")
            {
                MessageBox.Show("You must enter a food item ID.");
                return false;
            }
            else
            {
                ingredient.FoodItemID = Int32.Parse(txtFoodItemID.Text);
            }
            if (this.txtQuantity.Text == "")
            {
                MessageBox.Show("You must enter a quantity.");
                return false;
            }
            else
            {
                ingredient.Quantity = Int32.Parse(txtQuantity.Text);
            }
            if (this.txtUnit.Text == "")
            {
                MessageBox.Show("You must enter a unit of measurement.");
                return false;
            }
            else
            {
                ingredient.Unit = txtUnit.Text;
            }
            return true;
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            switch (_mode)
            {
                case DetailMode.Add:
                    setupAddMode();
                    break;
                default:
                    break;
            }
        }
    }
}
