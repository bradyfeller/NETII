﻿using DataTransferObjects;
using LogicLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace RestaurantSystem
{
    /// <summary>
    /// Interaction logic for frmRecipe.xaml
    /// </summary>
    public partial class frmRecipe : Window
    {
        private RecipeManager _recipeManager;
        private RecipeDetail _recipeDetail;
        private Recipe _recipe;
        private DetailMode _mode;

        public frmRecipe(RecipeManager reMgr, RecipeDetail reDetail, DetailMode mode)
        {
            _recipeManager = reMgr;
            _recipeDetail = reDetail;
            _mode = mode;

            InitializeComponent();
        }

        public frmRecipe(RecipeManager reMgr)
        {
            _recipeManager = reMgr;
            _mode = DetailMode.Add;

            InitializeComponent();
        }

        public frmRecipe()
        {
            InitializeComponent();
        }

        private void btnSaveEdit_Click(object sender, RoutedEventArgs e)
        {
            var newName = txtName.Text;
            var newInstructions = txtInstructions.Text;

            if (_mode == DetailMode.View)
            {
                _mode = DetailMode.Edit;
                setupEditMode();
                this.btnSaveEdit.Content = "Save";
                return;
            }

            if (_mode == DetailMode.Edit)
            {
                try
                {
                    _recipe = _recipeManager.UpdateRecipe(_recipeDetail.Recipe, newName, newInstructions);
                    this.DialogResult = true;
                }
                catch (Exception ex)
                {
                    var message = ex.Message + "\n\n" + ex.InnerException.Message;

                    MessageBox.Show("Update Failed!" + message);
                    return;
                }
            }

            var recipe = new Recipe();

            switch (_mode)
            {
                case DetailMode.Add:
                    // validate inputs and build the equipment
                    if (captureRecipe(recipe) == false)
                    {
                        return;
                    }
                    // pass it to a manager class method
                    try
                    {
                        if (_recipeManager.SaveNewRecipe(recipe))
                        {
                            this.DialogResult = true;
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                    break;
                case DetailMode.View:
                    break;
                default:
                    break;
            }
        }

        private void btnCancel_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = false;
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            switch (_mode)
            {
                case DetailMode.View:
                    setupViewMode();
                    break;
                case DetailMode.Edit:
                    setupEditMode();
                    break;
                case DetailMode.Add:
                    setupAddMode();
                    break;
                default:
                    break;
            }
        }

        private void populateControls()
        {
            this.txtRecipeID.Text = _recipeDetail.Recipe.RecipeID.ToString();
            this.txtMenuItemID.Text = _recipeDetail.Recipe.MenuItemID.ToString();
            this.txtName.Text = _recipeDetail.Recipe.Name;
            this.txtInstructions.Text = _recipeDetail.Recipe.Instructions;
        }

        private void setupViewMode()
        {
            this.btnSaveEdit.Content = "Edit";
            populateControls();
            setInputs(readOnly: true);
        }
        private void setupEditMode()
        {
            populateControls();
            setInputs(readOnly: false);
        }
        private void setupAddMode()
        {
            setInputs(readOnly: false);
        }

        private void setInputs(bool readOnly = true)
        {
            this.txtRecipeID.IsReadOnly = true;
            this.txtMenuItemID.IsReadOnly = readOnly;
            this.txtName.IsReadOnly = readOnly;
            this.txtInstructions.IsReadOnly = readOnly;
        }

        private bool captureRecipe(Recipe recipe)
        {

            if (this.txtName.Text == "")
            {
                MessageBox.Show("You must enter a name.");
                return false;
            }
            else
            {
                recipe.Name = txtName.Text;
            }
            if (this.txtInstructions.Text == "")
            {
                MessageBox.Show("You must enter some instructions.");
                return false;
            }
            else
            {
                recipe.Instructions = txtInstructions.Text;
            }
            return true;
        }
    }
}
