﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using LogicLayer;
using DataTransferObjects;

namespace RestaurantSystem
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private UserManager _userManager = new UserManager();
        private OrderManager _orderManager = new OrderManager();
        private FoodItemManager _foodItemManager = new FoodItemManager();
        private MenuItemManager _menuItemManager = new MenuItemManager();
        private RecipeManager _recipeManager = new RecipeManager();


        private List<Order> _orderList;
        private List<DataTransferObjects.MenuItem> _menuItemList;
        private List<FoodItem> _foodItemList;
        private List<Recipe> _recipeList;


        private User _user = null;

        private const int MIN_PASSWORD_LENGTH = 5;  // business rule
        private const int MIN_USERNAME_LENGTH = 8;  // forced by naming rules
        private const int MAX_USERNAME_LENGTH = 100;// forced by db field length        

        public MainWindow()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, RoutedEventArgs e)
        {
            if (_user != null) // this means someone is logged in, so log out!
            {
                logout();
                return;
            }

            // accept the input
            var username = txtUsername.Text;
            var password = txtPassword.Password;

            // check for missing or invalid data
            if (username.Length < MIN_USERNAME_LENGTH ||
                username.Length > MAX_USERNAME_LENGTH)
            {
                MessageBox.Show("Invalid Username", "Login Failed!",
                    MessageBoxButton.OK, MessageBoxImage.Exclamation);

                clearLogin();

                return;
            }
            if (password.Length <= MIN_PASSWORD_LENGTH)
            {
                MessageBox.Show("Invalid Password", "Login Failed!",
                    MessageBoxButton.OK, MessageBoxImage.Exclamation);

                clearLogin();
                return;
            }

            // before checking for the user token, we need to use a try block
            try
            {
                _user = _userManager.AuthenticateUser(username, password);

                if (_user.Roles.Count == 0)
                {
                    // check for unauthorized user
                    _user = null;

                    MessageBox.Show("You have not been assigned any roles. \nYou will be logged out. \nPlease see your supervisor.",
                        "Unauthorized Employee", MessageBoxButton.OK,
                        MessageBoxImage.Stop);

                    clearLogin();

                    return;
                }
                // user is now logged in
                var message = "Welcome back, " + _user.Employee.FirstName +
                    ". You are logged in as: ";
                foreach (var r in _user.Roles)
                {
                    message += r.RoleID + "   ";
                }

                showUserTabs();
                statusMain.Items[0] = message;

                clearLogin();
                txtPassword.Visibility = Visibility.Hidden;
                txtUsername.Visibility = Visibility.Hidden;
                lblPassword.Visibility = Visibility.Hidden;
                lblUsername.Visibility = Visibility.Hidden;

                this.btnLogin.IsDefault = false;
                btnLogin.Content = "Log Out";

                // check for expired password
                if (_user.PasswordMustBeChanged)
                {
                    changePassword();
                }


            }
            catch (Exception ex) // nowhere to throw an exception at the presentation layer
            {
                string message = ex.Message;

                if (ex.InnerException != null)
                {
                    message += "\n\n" + ex.InnerException.Message;
                }

                MessageBox.Show(message, "Login Failed!",
                    MessageBoxButton.OK, MessageBoxImage.Exclamation);

                clearLogin();
                return;
            }
        }

        private void logout()
        {
            _user = null;
            // do anything else we need to do to clear the screen, to be done later

            // reenable the login controls
            txtPassword.Visibility = Visibility.Visible;
            txtUsername.Visibility = Visibility.Visible;
            lblPassword.Visibility = Visibility.Visible;
            lblUsername.Visibility = Visibility.Visible;
            btnLogin.Content = "Log In";
            clearLogin();
            statusMain.Items[0] = "You are not logged in.";

            hideAllTabs();
        }

        private void changePassword()
        {
            // need to capture a new password from the user.
            var passwordChangeWindow = new frmUpdatePassword(_userManager, _user);
            var result = passwordChangeWindow.ShowDialog();

            if (result == true)
            {
                if (_user.Roles[0].RoleID == "New User")
                {
                    // log out
                    logout();
                    MessageBox.Show("You have been logged out.\nYou must log in again\nwith your new password to continue.", "Re-Login Required.");
                    return;
                }
                else // not a new user, so no need to logout and back in
                {
                    MessageBox.Show("Password Updated.");
                }
            }
            else
            {
                logout();
                MessageBox.Show("Password change cancelled. You are logged out.");
            }
        }

        private void clearLogin()
        {
            this.btnLogin.IsDefault = true;
            txtUsername.Text = "";
            txtPassword.Password = "";
            txtUsername.Focus();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            txtUsername.Focus();
            this.btnLogin.IsDefault = true;
            hideAllTabs();

            refreshOrderList();
            refreshMenuItemList();
            refreshFoodItemList();
            refreshRecipeList();
        }

        private void refreshOrderList(bool active = true)
        {
            try
            {
                _orderList = _orderManager.RetrieveOrderList(active);
            }
            catch (Exception ex)
            {
                var message = ex.Message + "\n\n" + ex.InnerException.Message;
                MessageBox.Show(message, "Data Retrieval Error!",
                    MessageBoxButton.OK, MessageBoxImage.Exclamation);
            }
        }

        private void refreshMenuItemList(bool active = true)
        {
            try
            {
                _menuItemList = _menuItemManager.RetrieveMenuItemList(active);
            }
            catch (Exception ex)
            {
                var message = ex.Message + "\n\n" + ex.InnerException.Message;
                MessageBox.Show(message, "Data Retrieval Error!",
                    MessageBoxButton.OK, MessageBoxImage.Exclamation);
            }
        }

        private void refreshFoodItemList(bool active = true)
        {
            try
            {
                _foodItemList = _foodItemManager.RetrieveFoodItemList(active);
            }
            catch (Exception ex)
            {
                var message = ex.Message + "\n\n" + ex.InnerException.Message;
                MessageBox.Show(message, "Data Retrieval Error!",
                    MessageBoxButton.OK, MessageBoxImage.Exclamation);
            }
        }

        private void refreshRecipeList(bool active = true)
        {
            try
            {
                _recipeList = _recipeManager.RetrieveRecipeList(active);
            }
            catch (Exception ex)
            {
                var message = ex.Message + "\n\n" + ex.InnerException.Message;
                MessageBox.Show(message, "Data Retrieval Error!",
                    MessageBoxButton.OK, MessageBoxImage.Exclamation);
            }
        }

        private void hideAllTabs()
        {
            foreach (var tab in tabsetMain.Items)
            {
                // collapse all the tabs
                ((TabItem)tab).Visibility = Visibility.Collapsed;
                // hide the tabset completely
                tabsetMain.Visibility = Visibility.Visible;
            }
            this.lblScreenCover.Visibility = Visibility.Visible;
        }

        private void showUserTabs()
        {
            this.lblScreenCover.Visibility = Visibility.Hidden;
            foreach (var r in _user.Roles)
            {
                switch (r.RoleID)
                {
                    case "Manager":
                        foreach (var tab in tabsetMain.Items)
                        {
                            ((TabItem)tab).Visibility = Visibility.Visible;
                        }
                        tabOrder.IsSelected = true;
                        break;
                    case "Waiter":
                        tabOrder.Visibility = Visibility.Visible;
                        tabOrder.IsSelected = true;
                        tabMenuItem.Visibility = Visibility.Visible;
                        break;
                    case "Chef":
                        tabOrder.Visibility = Visibility.Visible;
                        tabOrder.IsSelected = true;
                        tabMenuItem.Visibility = Visibility.Visible;
                        tabFoodItem.Visibility = Visibility.Visible;
                        tabRecipe.Visibility = Visibility.Visible;
                        break;
                }
            }
            tabsetMain.Visibility = Visibility.Visible;
        }

        private void dgOrder_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {

        }

        private void btnOrderDetails_Click(object sender, RoutedEventArgs e)
        {
            if (this.dgOrder.SelectedItems.Count == 0)
            {
                MessageBox.Show("You haven't selected anything!");
                return;
            }

            var frmOrderLine = new frmOrderLine(_orderManager, ((Order)(this.dgOrder.SelectedItem)).OrderID );
            var result = frmOrderLine.ShowDialog();
            if (result == true)
            {
                dgOrder.ItemsSource = _orderList;
                refreshOrderList();
                this.tabOrder.Focus();
                this.dgOrder.Focus();

            }
        }

        private void btnEditOrder_Click(object sender, RoutedEventArgs e)
        {
            if (this.dgOrder.SelectedItems.Count == 0)
            {
                MessageBox.Show("You haven't selected anything!");
                return;
            }

            var frmOrderStatus = new frmOrderStatus(_orderManager, ((Order)(this.dgOrder.SelectedItem)));
            var result = frmOrderStatus.ShowDialog();
            if (result == true)
            {
                dgOrder.ItemsSource = _orderList;
                refreshOrderList();
                this.tabOrder.Focus();
                this.dgOrder.Focus();

            }
        }

        private void btnAddOrder_Click(object sender, RoutedEventArgs e)
        {
            var frmAddOrder = new frmAddOrder(_orderManager);
            var result = frmAddOrder.ShowDialog();
            if (result == true)
            {
                dgOrder.ItemsSource = _orderList;
                refreshOrderList();
            }
        }

        private void tabOrder_GotFocus(object sender, RoutedEventArgs e)
        {
            dgOrder.ItemsSource = _orderList;
        }

        private void dgMenuItem_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            var menuItem = (DataTransferObjects.MenuItem)this.dgMenuItem.SelectedItem;
            var message = "You selected a " + menuItem.Name + ".";
            MessageBox.Show(message);
        }

        private void btnMenuItemDetails_Click(object sender, RoutedEventArgs e)
        {
            if (this.dgMenuItem.SelectedItems.Count == 0)
            {
                MessageBox.Show("You haven't selected anything!");
                return;
            }

            var menuItem = (DataTransferObjects.MenuItem)this.dgMenuItem.SelectedItem;
            var menuItemDetail = _menuItemManager.RetrieveMenuItemDetail(menuItem);

            var frmMenuItemDetails = new frmMenuItem(_menuItemManager, menuItemDetail, DetailMode.View);
            var result = frmMenuItemDetails.ShowDialog();
            if (result == true)
            {
                dgMenuItem.ItemsSource = _menuItemList;
                refreshMenuItemList();
                this.tabMenuItem.Focus();
                this.dgMenuItem.Focus();

            }
        }

        private void btnEditMenuItem_Click(object sender, RoutedEventArgs e)
        {
            if (this.dgMenuItem.SelectedItems.Count == 0)
            {
                MessageBox.Show("You haven't selected anything!");
                return;
            }

            var menuItem = (DataTransferObjects.MenuItem)this.dgMenuItem.SelectedItem;
            var menuItemDetail = _menuItemManager.RetrieveMenuItemDetail(menuItem);

            var frmMenuItemDetails = new frmMenuItem(_menuItemManager, menuItemDetail, DetailMode.Edit);
            var result = frmMenuItemDetails.ShowDialog();
            if (result == true)
            {
                dgMenuItem.ItemsSource = _menuItemList;
                refreshMenuItemList();
            }
        }

        private void btnAddMenuItem_Click(object sender, RoutedEventArgs e)
        {
            var frmMenuItemDetails = new frmMenuItem(_menuItemManager);
            var result = frmMenuItemDetails.ShowDialog();
            if (result == true)
            {
                dgMenuItem.ItemsSource = _menuItemList;
                refreshMenuItemList();
            }
        }

        private void tabMenuItem_GotFocus(object sender, RoutedEventArgs e)
        {
            dgMenuItem.ItemsSource = _menuItemList;
        }

        private void dgFoodItem_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            var foodItem = (FoodItem)this.dgFoodItem.SelectedItem;
            var message = "You selected a " + foodItem.Name + ".";
            MessageBox.Show(message);
        }

        private void btnFoodItemDetails_Click(object sender, RoutedEventArgs e)
        {
            if (this.dgFoodItem.SelectedItems.Count == 0)
            {
                MessageBox.Show("You haven't selected anything!");
                return;
            }

            var foodItem = (FoodItem)this.dgFoodItem.SelectedItem;
            var foodItemDetail = _foodItemManager.RetrieveFoodItemDetail(foodItem);

            var frmFoodItemDetails = new frmFoodItem(_foodItemManager, foodItemDetail, DetailMode.View);
            var result = frmFoodItemDetails.ShowDialog();
            if (result == true)
            {
                dgFoodItem.ItemsSource = _foodItemList;
                refreshFoodItemList();
                this.tabFoodItem.Focus();
                this.dgFoodItem.Focus();
                
            }
        }
        
        private void btnEditFoodItem_Click(object sender, RoutedEventArgs e)
        {
            if (this.dgFoodItem.SelectedItems.Count == 0)
            {
                MessageBox.Show("You haven't selected anything!");
                return;
            }

            var foodItem = (FoodItem)this.dgFoodItem.SelectedItem;
            var foodItemDetail = _foodItemManager.RetrieveFoodItemDetail(foodItem);

            var frmFoodItemDetails = new frmFoodItem(_foodItemManager, foodItemDetail, DetailMode.Edit);
            var result = frmFoodItemDetails.ShowDialog();
            if (result == true)
            {
                dgFoodItem.ItemsSource = _foodItemList;
                refreshFoodItemList();
            }
        }

        private void btnAddFoodItem_Click(object sender, RoutedEventArgs e)
        {
            var frmFoodItemDetails = new frmFoodItem(_foodItemManager);
            var result = frmFoodItemDetails.ShowDialog();
            if (result == true)
            {
                dgFoodItem.ItemsSource = _foodItemList;
                refreshFoodItemList();
            }
        }

        private void tabFoodItem_GotFocus(object sender, RoutedEventArgs e)
        {
            dgFoodItem.ItemsSource = _foodItemList;
        }

        private void btnDeactivateOrder_Click(object sender, RoutedEventArgs e)
        {
            if (dgOrder.SelectedItems.Count == 0)
            {
                MessageBox.Show("You need to select something!");
                return;
            }
            else
            {
                var result = MessageBox.Show("Deactivate " +
                    ((Order)(dgOrder.SelectedItem)).OrderID +
                    "? Are you sure?", "Deactivate Order",
                    MessageBoxButton.OKCancel, MessageBoxImage.Warning);

                if (result == MessageBoxResult.OK)
                {
                    _orderManager.DeactivateOrder((Order)dgOrder.SelectedItem);
                    refreshOrderList();
                }
                else
                {
                    return;
                }
            }
        }
        
        private void dgRecipe_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            var recipeItem = (Recipe)this.dgRecipe.SelectedItem;
            var message = "You selected a Recipe for " + recipeItem.Name + ".";
            MessageBox.Show(message);
        }
        
        private void btnEditRecipe_Click(object sender, RoutedEventArgs e)
        {
            if (this.dgRecipe.SelectedItems.Count == 0)
            {
                MessageBox.Show("You haven't selected anything!");
                return;
            }

            var recipe = (Recipe)this.dgRecipe.SelectedItem;
            var recipeDetail = _recipeManager.RetrieveRecipe(recipe);

            var frmRecipe = new frmRecipe(_recipeManager, recipeDetail, DetailMode.Edit);
            var result = frmRecipe.ShowDialog();
            if (result == true)
            {
                dgRecipe.ItemsSource = _menuItemList;
                refreshRecipeList();
                this.tabRecipe.Focus();
                this.dgRecipe.Focus();

            }
        }

        private void btnAddRecipe_Click(object sender, RoutedEventArgs e)
        {
            var frmRecipe = new frmRecipe(_recipeManager);
            var result = frmRecipe.ShowDialog();
            if (result == true)
            {dgRecipe.ItemsSource = _recipeList;
                refreshRecipeList();
            }
        }

        private void btnRecipeDetails_Click(object sender, RoutedEventArgs e)
        {
            if (this.dgRecipe.SelectedItems.Count == 0)
            {
                MessageBox.Show("You haven't selected anything!");
                return;
            }

            var recipe = (Recipe)this.dgRecipe.SelectedItem;
            var recipeDetail = _recipeManager.RetrieveRecipe(recipe);

            var frmRecipe = new frmRecipe(_recipeManager, recipeDetail, DetailMode.View);
            var result = frmRecipe.ShowDialog();
            if (result == true)
            {
                dgRecipe.ItemsSource = _menuItemList;
                refreshRecipeList();
                this.tabRecipe.Focus();
                this.dgRecipe.Focus();

            }
        }

        private void btnDeactivateRecipe_Click(object sender, RoutedEventArgs e)
        {
            if (dgRecipe.SelectedItems.Count == 0)
            {
                MessageBox.Show("You need to select something!");
                return;
            }
            else
            {
                var result = MessageBox.Show("Deactivate " +
                    ((Recipe)(dgRecipe.SelectedItem)).RecipeID +
                    "? Are you sure?", "Deactivate Recipe",
                    MessageBoxButton.OKCancel, MessageBoxImage.Warning);

                if (result == MessageBoxResult.OK)
                {
                    _recipeManager.DeactivateRecipe((Recipe)dgRecipe.SelectedItem);
                    refreshRecipeList();
                }
                else
                {
                    return;
                }
            }
        }

        private void btnDeactivateFoodItem_Click(object sender, RoutedEventArgs e)
        {
            if (dgFoodItem.SelectedItems.Count == 0)
            {
                MessageBox.Show("You need to select something!");
                return;
            }
            else
            {
                var result = MessageBox.Show("Deactivate " +
                    ((FoodItem)(dgFoodItem.SelectedItem)).FoodItemID +
                    "? Are you sure?", "Deactivate Food Item",
                    MessageBoxButton.OKCancel, MessageBoxImage.Warning);

                if (result == MessageBoxResult.OK)
                {
                    _foodItemManager.DeactivateFoodItem((FoodItem)dgFoodItem.SelectedItem);
                    refreshFoodItemList();
                }
                else
                {
                    return;
                }
            }
        }

        private void btnDeactivateMenuItem_Click(object sender, RoutedEventArgs e)
        {
            if (dgMenuItem.SelectedItems.Count == 0)
            {
                MessageBox.Show("You need to select something!");
                return;
            }
            else
            {
                var result = MessageBox.Show("Deactivate " +
                    ((DataTransferObjects.MenuItem)(dgMenuItem.SelectedItem)).MenuItemID +
                    "? Are you sure?", "Deactivate Menu Item",
                    MessageBoxButton.OKCancel, MessageBoxImage.Warning);

                if (result == MessageBoxResult.OK)
                {
                    _menuItemManager.DeactivateMenuItem((DataTransferObjects.MenuItem)dgMenuItem.SelectedItem);
                    refreshMenuItemList();
                }
                else
                {
                    return;
                }
            }
        }

        private void tabRecipe_GotFocus(object sender, RoutedEventArgs e)
        {
            dgRecipe.ItemsSource = _recipeList;
        }

        private void btnIngredients_Click(object sender, RoutedEventArgs e)
        {
            if (this.dgRecipe.SelectedItems.Count == 0)
            {
                MessageBox.Show("You haven't selected anything!");
                return;
            }

            var frmIngredient = new frmIngredient(_recipeManager, ((Recipe)(this.dgRecipe.SelectedItem)).MenuItemID);
            var result = frmIngredient.ShowDialog();
            if (result == true)
            {
                dgRecipe.ItemsSource = _orderList;
                refreshRecipeList();
                this.tabRecipe.Focus();
                this.dgRecipe.Focus();

            }
        }
    }
}
