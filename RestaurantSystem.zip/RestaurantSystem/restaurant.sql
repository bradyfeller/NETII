/* Check if database already exists and delete it if it does exist*/
IF EXISTS(SELECT 1 FROM master.dbo.sysdatabases WHERE name = 'restaurant') 
BEGIN
	DROP DATABASE restaurant
	print '' print '*** dropping database restaurant'
END
GO

print '' print '*** creating database restaurant'
GO
CREATE DATABASE restaurant
GO

print '' print '*** using database restaurant'
GO
USE [restaurant]
GO

print '' print '*** Creating Employee Table'
GO
/* ***** Object:  Table [dbo].[Employees]     ***** */
CREATE TABLE [dbo].[Employee](
	[EmployeeID] 	[nvarchar](20) 			NOT NULL,
	[FirstName]		[nvarchar](50)			NOT NULL,
	[LastName]		[nvarchar](100)			NOT NULL,
	[PhoneNumber]	[nvarchar](15)			NOT NULL,
	[Email]			[nvarchar](100)			NOT NULL,
	[PasswordHash]	[nvarchar](100)			NOT NULL DEFAULT '9c9064c59f1ffa2e174ee754d2979be80dd30db552ec03e7e327e9b1a4bd594e',
	[Active]		[bit]					NOT NULL DEFAULT 1,
	CONSTRAINT [pk_EmployeeID] PRIMARY KEY([EmployeeID] ASC),
	CONSTRAINT [ak_Email] UNIQUE ([Email] ASC)
)
GO

print '' print '*** Creating Index for Employee.Email'
GO
CREATE NONCLUSTERED INDEX [ix_Employee_Email] ON [dbo].[Employee]([Email]);
GO

print '' print '*** Inserting Employee Test Records'
GO
INSERT INTO [dbo].[Employee]
		([EmployeeID], [FirstName], [LastName], [PhoneNumber], [Email])
	VALUES
		('Employee001', 'Joanne', 'Smith', '3195556666', 'joanne@company.com'),
		('Employee002','Martin', 'Jones', '3195557777', 'martin@company.com'),
		('Employee003','Leo', 'Williams', '3195558888', 'leo@company.com')
GO

print '' print '*** Creating Roles Table'
GO
CREATE TABLE [dbo].[Role](
	[RoleID]				[nvarchar](50)			NOT NULL,
	[RoleDescription]		[nvarchar](250)			NOT NULL,
	CONSTRAINT [pk_RoleID] PRIMARY KEY([RoleID] ASC)
)
GO

print '' print '*** Inserting Role Records'
INSERT INTO [dbo].[Role]
		([RoleID], [RoleDescription])
	VALUES
		('Waiter', 'Maintains Orders'),
		('Chef', 'Preps Food'),
		('Manager', 'Manager')
GO

print '' print '*** Creating EmployeeRole Table'
GO
CREATE TABLE [dbo].[EmployeeRole](
	[EmployeeID]			[nvarchar](20)		NOT NULL,
	[RoleID]				[nvarchar](50)		NOT NULL,
	[Active]				[bit]				NOT NULL DEFAULT 1,
	CONSTRAINT [pk_EmployeeIDRoleID] PRIMARY KEY([EmployeeID] ASC, [RoleID] ASC)
)
GO

print '' print '*** Inserting EmployeeRole Records'
INSERT INTO [dbo].[EmployeeRole]
		([EmployeeId], [RoleId])
	VALUES
		('Employee001', 'Manager'),
		('Employee002', 'Chef'),
		('Employee003', 'Waiter')
GO


/* *** Foreign Key Constraints *** */

print '' print '*** Creating EmployeeRole EmployeeID foreign key'
GO
ALTER TABLE [dbo].[EmployeeRole]  WITH NOCHECK 
	ADD CONSTRAINT [FK_EmployeeID] FOREIGN KEY([EmployeeID])
	REFERENCES [dbo].[Employee] ([EmployeeID])
	ON UPDATE CASCADE
GO

print '' print '*** Creating EmployeeRole RoleID foreign key'
GO
ALTER TABLE [dbo].[EmployeeRole] WITH NOCHECK 
	ADD CONSTRAINT [FK_RoleID] FOREIGN KEY([RoleID])
	REFERENCES [dbo].[Role] ([RoleID])
	ON UPDATE CASCADE
GO


/* *** Stored Procedures *** */

print '' print '*** Creating sp_update_employee_email'
GO
CREATE PROCEDURE [dbo].[sp_update_employee_email]
	(
	@EmployeeID		[nvarchar](20),
	@Email			[nvarchar](100)
	)
AS
	BEGIN
		UPDATE [dbo].[Employee]
			SET 	[Email] = @Email
			WHERE 	[EmployeeID] = @EmployeeID
		RETURN @@ROWCOUNT
	END
GO

print '' print '*** Creating sp_authenticate_user'
GO
CREATE PROCEDURE [dbo].[sp_authenticate_user]
	(
	@Email			[nvarchar](100),
	@PasswordHash	[nvarchar](100)
	)
AS
	BEGIN
		SELECT COUNT([EmployeeID])
		FROM 	[Employee]
		WHERE 	[Email] = @Email
		AND 	[PasswordHash] = @PasswordHash
		AND		[Active] = 1
	END
GO

print '' print '*** Creating sp_retrieve_employee_roles'
GO
CREATE PROCEDURE [dbo].[sp_retrieve_employee_roles]
	(
	@EmployeeID		[nvarchar](20)
	)
AS
	BEGIN
		SELECT 	[RoleID]
		FROM 	[EmployeeRole]
		WHERE 	[EmployeeRole].[EmployeeID] = @EmployeeID
		AND		[Active] = 1
	END
GO

print '' print '*** Creating sp_update_passwordHash'
GO
CREATE PROCEDURE [dbo].[sp_update_passwordHash]
	(
	@EmployeeID			nvarchar(20),
	@OldPasswordHash	nvarchar(100),
	@NewPasswordHash	nvarchar(100)
	)
AS
	BEGIN
		UPDATE [Employee]
			SET [PasswordHash] = @NewPasswordHash
			WHERE [EmployeeID] = @EmployeeID
			AND [PasswordHash] = @OldPasswordHash
		RETURN @@ROWCOUNT
	END
GO

print '' print '*** Creating sp_retrieve_employee_by_email'
GO
CREATE PROCEDURE [dbo].[sp_retrieve_employee_by_email]
	(
	@Email		[nvarchar](100)
	)
AS
	BEGIN
		SELECT 	[EmployeeID], [FirstName], [LastName], [PhoneNumber], [Email], [Active]
		FROM 	[Employee]
		WHERE 	[Email] = @Email
	END
GO	

print '' print '*** Creating sp_update_employee_profile'
GO
CREATE PROCEDURE [dbo].[sp_update_employee_profile]
	(
	@NewFirstName	[nvarchar](50),
	@NewLastName	[nvarchar](100),
	@NewPhoneNumber	[nvarchar](15),
	@OldFirstName	[nvarchar](50),
	@OldLastName	[nvarchar](100),
	@OldPhoneNumber	[nvarchar](15),
	@EmployeeID		[nvarchar](20)
	)
AS
	BEGIN
		UPDATE [Employee]
			SET 	[FirstName] = @NewFirstName,
					[LastName] = @NewLastName,
					[PhoneNumber] = @NewPhoneNumber
			WHERE 	[EmployeeID] = @EmployeeID
			  AND	[FirstName] = @OldFirstName
			  AND	[LastName] = @OldLastName
			  AND	[PhoneNumber] = @OldPhoneNumber
		RETURN @@ROWCOUNT		
	END
GO

print '' print '*** Creating sp_deactive_employee'
GO
CREATE PROCEDURE [dbo].[sp_deactive_employee]
	(
	@EmployeeID			[nvarchar](20)
	)
AS
	BEGIN
		UPDATE [Employee]
			SET [Active] = 0
			WHERE [EmployeeID] = @EmployeeID
		RETURN @@ROWCOUNT
	END
GO

print '' print '*** Creating sp_add_employee'
GO
CREATE PROCEDURE [dbo].[sp_add_employee]
	(
	@EmployeeID			[nvarchar](20),
	@FirstName			[nvarchar](50),
	@LastName			[nvarchar](100),
	@PhoneNumber		[nvarchar](15),
	@Email				[nvarchar](100)
	)
AS
	BEGIN
		INSERT INTO [dbo].[Employee]
			([EmployeeID], [FirstName], [LastName], [PhoneNumber], [Email])
		VALUES
			(@EmployeeID, @FirstName, @LastName, @PhoneNumber, @Email)
	END
GO

print '' print '*** Creating Order Table'
GO
CREATE TABLE [dbo].[Order](
	[OrderID] 		[int] IDENTITY 	(100000,1) 	NOT NULL,
	[EmployeeID]	[nvarchar](20)				NOT NULL,
	[OrderPlaced]	[DateTime]					NOT NULL,
	[OrderStatusID]	[nvarchar](50)				NOT NULL DEFAULT 'Order Placed',
	[Active]		[bit]						NOT NULL DEFAULT 1,
	
	CONSTRAINT [pk_OrderID] PRIMARY KEY([OrderID] ASC)
)
GO

print '' print '*** Inserting Order Records'
INSERT INTO [dbo].[Order]
		([EmployeeID], [OrderPlaced], [OrderStatusID])
	VALUES
		('Employee002', '2017-06-12 12:12:15', 'Order Placed'),
		('Employee002', '2017-05-21 13:21:24', 'Complete'),
		('Employee002', '2017-12-23 14:32:33', 'Being Prepared'),
		('Employee002', '2017-11-19 15:21:42', 'Order Placed'),
		('Employee002', '2017-08-12 16:42:51', 'Complete')
GO

print '' print '*** Creating OrderLine Table'
GO
CREATE TABLE [dbo].[OrderLine](
	[OrderID] 		[int] 				NOT NULL,
	[MenuItemID]	[int]				NOT NULL,
	[Active]		[bit]		        NOT NULL DEFAULT 1,
	
	CONSTRAINT [pk_OrderIDMenuItemID] PRIMARY KEY([OrderID] ASC, [MenuItemID] ASC)
)
GO

print '' print '*** Inserting OrderLine Records'
INSERT INTO [dbo].[OrderLine]
		([OrderID], [MenuItemID])
	VALUES
		(100001, 100008),
		(100001, 100002),
		(100001, 100007),
		(100001, 100001),
		(100002, 100002),
		(100003, 100003),
		(100004, 100004),
		(100005, 100005)
GO

print '' print '*** Creating OrderStatus Table'
GO
CREATE TABLE [dbo].[OrderStatus](
	[OrderStatusID]		[nvarchar](50)			NOT NULL,
	
	CONSTRAINT [pk_OrderStatusID] PRIMARY KEY([OrderStatusID] ASC)
)
GO

print '' print '*** Inserting OrderStatus Records'
INSERT INTO [dbo].[OrderStatus]
		([OrderStatusID])
	VALUES
		('Order Placed'),
		('Being Prepared'),
		('Complete')
GO

print '' print '*** Creating MenuItem Table'
GO
CREATE TABLE [dbo].[MenuItem](
	[MenuItemID]	[int] IDENTITY (100000,1)	NOT NULL,
	[Name]			[nvarchar](50)				NOT NULL,
	[Description]	[nvarchar](100)				NOT NULL,
	[Active]		[bit]						NOT NULL DEFAULT 1,
	
	CONSTRAINT [pk_MenuItemID] PRIMARY KEY([MenuItemID] ASC)
)
GO

print '' print '*** Inserting MenuItem Records'
INSERT INTO [dbo].[MenuItem]
		([Name], [Description])
	VALUES
		('Chicken', 'A peice of chicken'),
		('Hamburger', 'Some hamburger bits'),
		('Meatloaf', 'Meat baked into  a loaf'),
		('Steak', 'From  A cow'),
		('Another Salad', 'Some more mixed greens'),
		('Salad', 'Mixed greens'),
		('Cheeseburger', 'Hamburger with cheese on top'),
		('Hamburger', 'Hamburger w/ out cheese'),
		('Hot Wings', 'Wings that are hot'),
		('Wings', 'Wings that are not hot')
GO

print '' print '*** Creating Recipe Table'
GO
CREATE TABLE [dbo].[Recipe](
	[RecipeID] 		[int] IDENTITY 	(100000,1) 	NOT NULL,
	[MenuItemID]	[int] 						NULL,
	[Name]			[nvarchar](50)				NOT NULL,
	[Instructions]	[nvarchar](250)				NOT NULL,
	[Active]		[bit]						NOT NULL DEFAULT 1,
	
	CONSTRAINT [pk_RecipeID] PRIMARY KEY([RecipeID] ASC)
)
GO

print '' print '*** Inserting Recipe Records'
INSERT INTO [dbo].[Recipe]
		([MenuItemID], [Name], [Instructions])
	VALUES
		(100000, 'Chicken', 'A greasy piece of chicken.'),
		(100001, 'Hamburger', 'I thinks its supposed to be a hamburger.'),
		(100002, 'Meatloaf', 'Leftovers from someones uneaten steak.'),
		(100003, 'Steak', 'Unprocessed hamburger.'),
		(100004, 'Another Salad', 'Some more grass in a bowl.'),
		(100005, 'Salad', 'Grass in a bowl.'),
		(100006, 'Cheeseburger', 'Hamburger with what appears to be cheese.')
GO

print '' print '*** Creating Ingredient Table'
GO
CREATE TABLE [dbo].[Ingredient](
	[MenuItemID]	[int] 			NOT NULL,
	[FoodItemID]	[int]			NOT NULL,
	[Quantity]		[int]			NOT NULL,
	[Unit]			[nvarchar](50)	NOT NULL,
	[Active]		[bit]			NOT NULL DEFAULT 1,
	
	CONSTRAINT [pk_MenuItemIDFoodItemID] PRIMARY KEY([MenuItemID] ASC, [FoodItemID] ASC)
)
GO

print '' print '*** Inserting Ingredient Records'
INSERT INTO [dbo].[Ingredient]
		([MenuItemID], [FoodItemID], [Quantity], [Unit])
	VALUES
		(100002, 400002, 4, '1oz'),
		(100005, 400005, 1, '8oz'),
		(100007, 400006, 1, '3oz'),
		(100007, 400009, 1, '1oz'),
		(100007, 400010, 1, '1lb')
	
GO

print '' print '*** Creating FoodItem Table'
GO
CREATE TABLE [dbo].[FoodItem](
	[FoodItemID] 	[int]	IDENTITY (100000,1)		NOT NULL,
	[Name]			[nvarchar](50)					NOT NULL,
	[Description]	[nvarchar](100)					NOT NULL,
	[Active]		[bit]							NOT NULL DEFAULT 1,
	
	CONSTRAINT [pk_FoodItemID] PRIMARY KEY([FoodItemID] ASC)
)
GO

print '' print '*** Inserting FoodItem Records'
INSERT INTO [dbo].[FoodItem]
		([Name], [Description])
	VALUES
		('Chicken Product', 'Kind of bird'),
		('Ground Beef', 'Comes from a Cow that walks on 4 legs'),
		('Mustard', 'A yellow sauce'),
		('Sirloin Steak', 'Another part of a cow'),
		('Grass', 'It grows outside'),
		('Spice', 'Combination of spices'),
		('Lettuce', 'Also some grass'),
		('Mushrooms', 'Fungi'),
		('Rocks', '...'),
		('Assorted Candy', 'Sweet'),
		('Sugar-free sugar', 'not sweet')
GO


/* *** Foreign Key Constraints *** */

print '' print '*** Creating OrderLine OrderID foreign key'
GO
ALTER TABLE [dbo].[OrderLine] WITH NOCHECK 
	ADD CONSTRAINT [FK_OrderID] FOREIGN KEY([OrderID])
	REFERENCES [dbo].[Order] ([OrderID])
	ON UPDATE CASCADE
GO

print '' print '*** Creating OrderLine MenuItemID foreign key'
GO
ALTER TABLE [dbo].[OrderLine] WITH NOCHECK 
	ADD CONSTRAINT [FK_OrderLineMenuItemID] FOREIGN KEY([MenuItemID])
	REFERENCES [dbo].[MenuItem] ([MenuItemID])
	ON UPDATE CASCADE
GO

print '' print '*** Creating Ingredient MenuItemID foreign key'
GO
ALTER TABLE [dbo].[Ingredient] WITH NOCHECK 
	ADD CONSTRAINT [FK_IngredientMenuItemID] FOREIGN KEY([MenuItemID])
	REFERENCES [dbo].[MenuItem] ([MenuItemID])
	ON UPDATE CASCADE
GO

print '' print '*** Creating Ingredient FoodItemID foreign key'
GO
ALTER TABLE [dbo].[Ingredient] WITH NOCHECK 
	ADD CONSTRAINT [FK_IngredientFoodItemID] FOREIGN KEY([FoodItemID])
	REFERENCES [dbo].[FoodItem] ([FoodItemID])
	ON UPDATE CASCADE
GO

print '' print '*** Creating OrderLine OrderStatusID foreign key'
GO
ALTER TABLE [dbo].[Order] WITH NOCHECK 
	ADD CONSTRAINT [FK_OrderOrderStatusID] FOREIGN KEY([OrderStatusID])
	REFERENCES [dbo].[OrderStatus] ([OrderStatusID])
	ON UPDATE CASCADE
GO


/* *** Stored Procedures *** */

/* Add */

print '' print '*** Creating sp_insert_order'
GO
CREATE PROCEDURE [dbo].[sp_insert_order]
	(
	@EmployeeID			[nvarchar](20),
	@OrderPlaced		[DateTime]
	)
AS
	BEGIN
		INSERT INTO [dbo].[Order]
			([EmployeeID], [OrderPlaced])
		VALUES
			(@EmployeeID, @OrderPlaced)
		SELECT SCOPE_IDENTITY()
	END
GO

print '' print '*** Creating sp_insert_order_line'
GO
CREATE PROCEDURE [dbo].[sp_insert_order_line]
	(
	@OrderID		[int],
	@MenuItemID		[int]
	)
AS
	BEGIN
		INSERT INTO [dbo].[OrderLine]
			([OrderID], [MenuItemID])
		VALUES
			(@OrderID, @MenuItemID)
		SELECT SCOPE_IDENTITY()
	END
GO

print '' print '*** Creating sp_insert_menu_item'
GO
CREATE PROCEDURE [dbo].[sp_insert_menu_item]
	(
	@Name			[nvarchar](50),
	@Description	[nvarchar](100)
	)
AS
	BEGIN
		INSERT INTO [dbo].[MenuItem]
			([Name], [Description])
		VALUES
			(@Name, @Description)
		SELECT SCOPE_IDENTITY()
	END
GO

print '' print '*** Creating sp_insert_recipe'
GO
CREATE PROCEDURE [dbo].[sp_insert_recipe]
	(
	@MenuItemID		[int],
	@Name			[nvarchar](50),
	@Instructions	[nvarchar](250)
	)
AS
	BEGIN
		INSERT INTO [dbo].[Recipe]
			([MenuItemID], [Name], [Instructions])
		VALUES
			(@MenuItemID, @Name, @Instructions)
		SELECT SCOPE_IDENTITY()
	END
GO

print '' print '*** Creating sp_insert_ingredient'
GO
CREATE PROCEDURE [dbo].[sp_insert_ingredient]
	(
	@MenuItemID		[int],
	@FoodItemID		[int],
	@Quantity		[int],
	@Unit			[nvarchar](50)
	)
AS
	BEGIN
		INSERT INTO [dbo].[Ingredient]
			([MenuItemID], [FoodItemID], [Quantity], [Unit])
		VALUES
			(@MenuItemID, @FoodItemID, @Quantity, @Unit)
		SELECT SCOPE_IDENTITY()
	END
GO

print '' print '*** Creating sp_insert_food_item'
GO
CREATE PROCEDURE [dbo].[sp_insert_food_item]
	(
	@Name			[nvarchar](50),
	@Description	[nvarchar](100)
	)
AS
	BEGIN
		INSERT INTO [dbo].[FoodItem]
			([Name], [Description])
		VALUES
			(@Name, @Description)
		SELECT SCOPE_IDENTITY()
	END
GO

/* retrieve by id */
print'' print'*** Creating sp_retrieve_order_by_id'
GO
CREATE PROCEDURE [dbo].[sp_retrieve_order_by_id]
	(
	@OrderID 	[int]
	)
AS
	BEGIN
		SELECT	[OrderID], [EmployeeID], [OrderPlaced], [OrderStatusID], [Active]
		FROM	[Order]
		WHERE	[Order].[OrderID] = @OrderID
	END
GO

print'' print'*** Creating sp_retrieve_orderline_by_id'
GO
CREATE PROCEDURE [dbo].[sp_retrieve_orderline_by_id]
	(
	@OrderID 		[int]
	)
AS
	BEGIN
		SELECT	[OrderID], [MenuItemID], [Active]
		FROM	[OrderLine]
		WHERE	[OrderLine].[OrderID] = @OrderID
	END
GO

print'' print'*** Creating sp_retrieve_menuitem_by_id'
GO
CREATE PROCEDURE [dbo].[sp_retrieve_menuitem_by_id]
	(
	@MenuItemID 	[int]
	)
AS
	BEGIN
		SELECT	[MenuItemID], [Name], [Description], [Active]
		FROM	[MenuItem]
		WHERE	[MenuItem].[MenuItemID] = @MenuItemID
	END
GO

print'' print'*** Creating sp_retrieve_recipe_by_id'
GO
CREATE PROCEDURE [dbo].[sp_retrieve_recipe_by_id]
	(
	@RecipeID	[int]
	)
AS
	BEGIN
		SELECT	[RecipeID], [MenuItemID], [Name], [Instructions], [Active]
		FROM	[Recipe]
		WHERE	[Recipe].[RecipeID] = @RecipeID
	END
GO

print'' print'*** Creating sp_retrieve_ingredient_by_id'
GO
CREATE PROCEDURE [dbo].[sp_retrieve_ingredient_by_id]
	(
	@MenuItemID 	[int],
	@FoodItemID		[int]
	)
AS
	BEGIN
		SELECT	[MenuItemID], [FoodItemID], [Quantity], [Unit], [Active]
		FROM	[Ingredient]
		WHERE	[Ingredient].[MenuItemID] = @MenuItemID
	END
GO

print'' print'*** Creating sp_retrieve_fooditem_by_id'
GO
CREATE PROCEDURE [dbo].[sp_retrieve_fooditem_by_id]
	(
	@FoodItemID 	[int]
	)
AS
	BEGIN
		SELECT	[FoodItemID], [Name], [Description], [Active]
		FROM	[FoodItem]
		WHERE	[FoodItem].[FoodItemID] = @FoodItemID
	END
GO

/* Retrieve by Active */
print'' print'*** Creating sp_retrieve_order_by_active'
GO
CREATE PROCEDURE [dbo].[sp_retrieve_order_by_active]
	(
	@Active 	[bit]
	)
AS
	BEGIN
		SELECT	[OrderID], [EmployeeID], [OrderPlaced], [OrderStatusID], [Active]
		FROM	[Order]
		WHERE	[Active] = @Active
	END
GO

print'' print'*** Creating sp_retrieve_orderline'
GO
CREATE PROCEDURE [dbo].[sp_retrieve_orderline]
	(
	@OrderID	[int]
	)
AS
	BEGIN
		SELECT	[OrderID], [MenuItemID], [Active]
		FROM	[OrderLine]
		WHERE   [OrderID] = @OrderID
	END
GO

print'' print'*** Creating sp_retrieve_order_status_list'
GO
CREATE PROCEDURE [dbo].[sp_retrieve_order_status_list]
AS
	BEGIN
		SELECT		[OrderStatusID]
		FROM		[OrderStatus]
		ORDER BY	[OrderStatusID]
	END
GO

print'' print'*** Creating sp_retrieve_ingredient'
GO
CREATE PROCEDURE [dbo].[sp_retrieve_ingredient]
	(
	@MenuItemID	[int]
	)
AS
	BEGIN
		SELECT	[MenuItemID], [FoodItemID], [Quantity], [Unit], [Active]
		FROM	[Ingredient]
		WHERE   [MenuItemID] = @MenuItemID
	END
GO


print'' print'*** Creating sp_retrieve_menuitem_by_active'
GO
CREATE PROCEDURE [dbo].[sp_retrieve_menuitem_by_active]
	(
	@Active 	[bit]
	)
AS
	BEGIN
		SELECT	[MenuItemID], [Name], [Description], [Active]
		FROM	[MenuItem]
		WHERE	[Active] = @Active
	END
GO

print'' print'*** Creating sp_retrieve_recipe_by_active'
GO
CREATE PROCEDURE [dbo].[sp_retrieve_recipe_by_active]
	(
	@Active 	[bit]
	)
AS
	BEGIN
		SELECT	[RecipeID], [MenuItemID], [Name], [Instructions], [Active]
		FROM	[Recipe]
		WHERE	[Active] = @Active
	END
GO

print'' print'*** Creating sp_retrieve_fooditem_by_active'
GO
CREATE PROCEDURE [dbo].[sp_retrieve_fooditem_by_active]
	(
	@Active 	[bit]
	)
AS
	BEGIN
		SELECT	[FoodItemID], [Name], [Description], [Active]
		FROM	[FoodItem]
		WHERE	[Active] = @Active
	END
GO

/* Update */
print'' print'*** Creating sp_update_menu_item'
GO
CREATE PROCEDURE [dbo].[sp_update_menu_item]
	(
	@NewName			[nvarchar](50),
	@OldName			[nvarchar](50),
	@NewDescription		[nvarchar](100),
	@OldDescription		[nvarchar](100),
	@MenuItemID			[int]
	)
AS
	BEGIN
		UPDATE [MenuItem]
			SET 	[Name] = @NewName,
					[Description] = @NewDescription
			WHERE 	[MenuItemID] = @MenuItemID
			  AND	[Name] = @OldName
			  AND 	[Description] = @OldDescription
		RETURN
	END
GO

print'' print'*** Creating sp_update_order'
GO
CREATE PROCEDURE [dbo].[sp_update_order]
	(
	@OrderStatusID		[nvarchar](50),
	@OrderID			[int]
	)
AS
	BEGIN
		UPDATE [Order]
			SET 	[OrderStatusID] = @OrderStatusID
			WHERE 	[OrderID] = @OrderID
		RETURN
	END
GO

print'' print'*** Creating sp_update_recipe'
GO
CREATE PROCEDURE [dbo].[sp_update_recipe]
	(
	@NewName			[nvarchar](50),
	@OldName			[nvarchar](50),
	@NewInstructions	[nvarchar](250),
	@OldInstructions	[nvarchar](250),
	@RecipeID			[int]
	)
AS
	BEGIN
		UPDATE [Recipe]
			SET 	[Name] = @NewName,
					[Instructions] = @NewInstructions
			WHERE 	[RecipeID] = @RecipeID
			  AND	[Name] = @OldName
			  AND 	[Instructions] = @OldInstructions
		RETURN
	END
GO

print'' print'*** Creating sp_update_food_item'
GO
CREATE PROCEDURE [dbo].[sp_update_food_item]
	(
	@NewName			[nvarchar](50),
	@OldName			[nvarchar](50),
	@NewDescription		[nvarchar](100),
	@OldDescription		[nvarchar](100),
	@FoodItemID			[int]
	)
AS
	BEGIN
		UPDATE [FoodItem]
			SET 	[Name] = @NewName,
					[Description] = @NewDescription
			WHERE 	[FoodItemID] = @FoodItemID
			  AND	[Name] = @OldName
			  AND	[Description] = @OldDescription
		RETURN
	END
GO


/* Deactivate */
print'' print'*** Creating sp_deactivate_order'
GO
CREATE PROCEDURE [dbo].[sp_deactivate_order]
	(
	@OrderID 	[int]
	)
AS
	BEGIN
		UPDATE [Order]
			SET [Active] = 0
			WHERE [OrderID] = @OrderID
		RETURN @@ROWCOUNT
	END
GO

print'' print'*** Creating sp_deactivate_order_line'
GO
CREATE PROCEDURE [dbo].[sp_deactivate_order_line]
	(
	@OrderID 		[int],
	@MenuItemID		[int]
	)
AS
	BEGIN
		UPDATE [OrderLine]
			SET [Active] = 0
			WHERE [OrderID] = @OrderID
			AND [MenuItemID] = @MenuItemID
		RETURN @@ROWCOUNT
	END
GO

print'' print'*** Creating sp_deactivate_ingredient'
GO
CREATE PROCEDURE [dbo].[sp_deactivate_ingredient]
	(
	@MenuItemID 	[int],
	@FoodItemID		[int]
	)
AS
	BEGIN
		UPDATE [Ingredient]
			SET [Active] = 0
			WHERE [MenuItemID] = @MenuItemID
			AND [FoodItemID] = @FoodItemID
		RETURN @@ROWCOUNT
	END
GO

print'' print'*** Creating sp_deactivate_menu_item'
GO
CREATE PROCEDURE [dbo].[sp_deactivate_menu_item]
	(
	@MenuItemID 	[int]
	)
AS
	BEGIN
		UPDATE [MenuItem]
			SET [Active] = 0
			WHERE [MenuItemID] = @MenuItemID
		RETURN @@ROWCOUNT
	END
GO

print'' print'*** Creating sp_deactivate_food_item'
GO
CREATE PROCEDURE [dbo].[sp_deactivate_food_item]
	(
	@FoodItemID 	[int]
	)
AS
	BEGIN
		UPDATE [FoodItem]
			SET [Active] = 0
			WHERE [FoodItemID] = @FoodItemID
		RETURN @@ROWCOUNT
	END
GO

print'' print'*** Creating sp_deactivate_recipe'
GO
CREATE PROCEDURE [dbo].[sp_deactivate_recipe]
	(
	@RecipeID 	[int]
	)
AS
	BEGIN
		UPDATE [Recipe]
			SET [Active] = 0
			WHERE [RecipeID] = @RecipeID
		RETURN @@ROWCOUNT
	END
GO