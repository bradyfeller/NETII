﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataTransferObjects;
using DataAccessLayer;

namespace LogicLayer
{
    public class OrderManager
    {
        public List<Order> RetrieveOrderList(bool active = true)
        {
            List<Order> orderList = null;

            try
            {
                orderList = OrderAccessor.RetrieveOrderByActive(active);
            }
            catch (Exception)
            {
                throw;
            }

            return orderList;
        }

        public List<OrderLine> RetrieveOrderLineList(int orderID)
        {
            List<OrderLine> orderLineList = null;

            try
            {
                orderLineList = OrderAccessor.RetrieveOrderLineByID(orderID);
            }
            catch (Exception)
            {
                throw;
            }

            return orderLineList;
        }

        public List<OrderStatus> RetrieveOrderStatusList()
        {
            try
            {
                return OrderAccessor.RetrieveOrderStatus();
            }
            catch (Exception)
            {
                throw;
            }
        }

        public bool DeactivateOrder(Order order)
        {
            bool result = false;

            try
            {
                result = (1 == OrderAccessor.DeactivateOrder(order.OrderID));
            }
            catch (Exception ex)
            {
                throw new ApplicationException("Order Deactivation failed.", ex);
            }

            return true;
        }

        public Order UpdateOrder(Order order, string orderStatusID)
        {
            int rowsAffected = 0;

            try
            {
                rowsAffected = OrderAccessor.UpdateOrder(order.OrderID, orderStatusID);

                if (rowsAffected == 1)
                {
                    order.OrderStatusID = orderStatusID;
                }
                else
                {
                    throw new ApplicationException("Update returned 0 rows affected.");
                }
            }
            catch (Exception ex)
            {
                throw new ApplicationException("Password change failed.", ex);
            }

            return order;
        }

        public bool DeactivateOrderLine(OrderLine orderLine)
        {
            bool result = false;

            try
            {
                result = (1 == OrderAccessor.DeactivateOrderLine(orderLine.OrderID, orderLine.MenuItemID));
            }
            catch (Exception ex)
            {
                throw new ApplicationException("Order Deactivation failed.", ex);
            }

            return true;
        }

        public bool SaveNewOrder(Order order)
        {
            var result = false;

            if (order.EmployeeID == "")
            {
                throw new ApplicationException("You must fill out all the fields.");
            }
            try
            {
                result = (0 != OrderAccessor.InsertOrder(order));
            }
            catch (Exception)
            {
                throw;
            }
            return result;
        }

        public bool SaveNewOrderLine(OrderLine orderLine)
        {
            var result = false;

            if (orderLine.OrderID < 100000 || orderLine.MenuItemID < 100000)
            {
                throw new ApplicationException("You must fill out all the fields.");
            }
            try
            {
                result = (0 != OrderAccessor.InsertOrderLine(orderLine));
            }
            catch (Exception)
            {
                throw;
            }
            return result;
        }
    }
}