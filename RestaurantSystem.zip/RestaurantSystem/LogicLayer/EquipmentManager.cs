﻿using DataTransferObjects;
using DataAccessLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LogicLayer
{
    public class EquipmentManager
    {
        public List<Equipment> RetrieveEquipmentList(bool active = true)
        {
            List<Equipment> equipmentList = null;

            try
            {
                equipmentList = EquipmentAccessor.RetrieveEquipmentByActive(active);
            }
            catch (Exception)
            {
                throw;
            }

            return equipmentList;
        }

        public EquipmentDetail RetrieveEquipmentDetail(Equipment equipmentItem)
        {
            EquipmentDetail equipmentDetail = null;
            PrepList prepList = null;
            InspectionList inspectionList = null;
            EquipmentModel equipmentModel = null;

            try
            {
                if (equipmentItem.PrepListID != null)
                {
                    prepList = EquipmentAccessor.RetrievePrepListByID((int)equipmentItem.PrepListID);
                }
                if (equipmentItem.InspectionListID != null)
                {
                    inspectionList = EquipmentAccessor.RetrieveInspectionListByID((int)equipmentItem.InspectionListID);
                }
                equipmentModel = EquipmentAccessor.RetrieveEquipmentModelByID(equipmentItem.EquipmentModelID);
                equipmentDetail = new EquipmentDetail()
                {
                    Equipment = equipmentItem,
                    EquipmentModel = equipmentModel,
                    InspectionList = inspectionList,
                    PrepList = prepList
                };
            }
            catch (Exception)

            {
                throw;
            }

            return equipmentDetail;
        }

        public List<Status> RetrieveStatusList()
        {
            try
            {
                return EquipmentAccessor.RetrieveStatusList();
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}
