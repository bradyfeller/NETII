﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataTransferObjects;
using DataAccessLayer;

namespace LogicLayer
{
    public class FoodItemManager
    {
        public FoodItem UpdateFoodItem(FoodItem foodItem, string newName, string newDescription)
        {
            int rowsAffected = 0;

            try
            {
                rowsAffected = FoodItemAccessor.UpdateFoodItem(foodItem.FoodItemID, newName, foodItem.Name, newDescription, foodItem.Description);

                if (rowsAffected == 1)
                {
                    foodItem.Name = newName;
                    foodItem.Description  = newDescription;
                }
                else
                {
                    throw new ApplicationException("Update returned 0 rows affected.");
                }
            }
            catch (Exception ex)
            {
                throw new ApplicationException("Password change failed.", ex);
            }

            return foodItem;
        }

        public FoodItemDetail RetrieveFoodItemDetail(FoodItem foodItem)
        {
            FoodItemDetail foodItemDetail = null;
            FoodItem food = null;

            try
            {
                food = FoodItemAccessor.RetrieveFoodItemByID(foodItem.FoodItemID);
                foodItemDetail = new FoodItemDetail()
                {
                    FoodItem = foodItem
                };
            }
            catch (Exception)
            {
                throw;
            }

            return foodItemDetail;
        }

        public List<FoodItem> RetrieveFoodItemList(bool active = true)
        {
            List<FoodItem> foodItemList = null;

            try
            {
                foodItemList = FoodItemAccessor.RetrieveFoodItemByActive(active);
            }
            catch (Exception)
            {
                throw;
            }

            return foodItemList;
        }

        public bool DeactivateFoodItem(FoodItem foodItem)
        {
            bool result = false;

            try
            {
                result = (1 == FoodItemAccessor.DeactivateFoodItem(foodItem.FoodItemID));
            }
            catch (Exception ex)
            {
                throw new ApplicationException("Food Item Deactivation failed.", ex);
            }

            return true;
        }

        public bool SaveNewFoodItem(FoodItem foodItem)
        {
            var result = false;

            if (foodItem.Name == "" || foodItem.Description == "")
            {
                throw new ApplicationException("You must fill out all the fields.");
            }
            try
            {
                result = (0 != FoodItemAccessor.InsertFoodItem(foodItem));
            }
            catch (Exception)
            {
                throw;
            }
            return result;
        }
    }
}
