﻿using DataAccessLayer;
using DataTransferObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LogicLayer
{
    public class RecipeManager
    {
        public List<Recipe> RetrieveRecipeList(bool active = true)
        {
            List<Recipe> recipeList = null;

            try
            {
                recipeList = RecipeAccessor.RetrieveRecipeByActive(active);
            }
            catch (Exception)
            {
                throw;
            }

            return recipeList;
        }

        public RecipeDetail RetrieveRecipe(Recipe recipeItem)
        {
            
            RecipeDetail recipeDetail = null;
            Recipe recipe = null;
            

            try
            {
                recipe = RecipeAccessor.RetrieveRecipeByID((int)recipeItem.RecipeID);
                recipeDetail = new RecipeDetail()
                {
                    Recipe = recipeItem
                };
                
            }
            catch (Exception)

            {
                throw;
            }

            return recipeDetail;
        }

        public List<Ingredient> RetrieveIngredientList(int menuItemID)
        {
            List<Ingredient> ingredientList = null;

            try
            {
                ingredientList = RecipeAccessor.RetrieveIngredientByID(menuItemID);
            }
            catch (Exception)
            {
                throw;
            }

            return ingredientList;
        }

        public bool DeactivateRecipe(Recipe recipe)
        {
            bool result = false;

            try
            {
                result = (1 == RecipeAccessor.DeactivateRecipe(recipe.RecipeID));
            }
            catch (Exception ex)
            {
                throw new ApplicationException("Recipe Deactivation failed.", ex);
            }

            return true;
        }

        public bool SaveNewRecipe(Recipe recipe)
        {
            var result = false;

            if (recipe.Name == "" || recipe.Instructions == "")
            {
                throw new ApplicationException("You must fill out all the fields.");
            }
            try
            {
                result = (0 !=RecipeAccessor.InsertRecipe(recipe));
            }
            catch (Exception)
            {
                throw;
            }
            return result;
        }

        public Recipe UpdateRecipe(Recipe recipe, string newName, string newInstructions)
        {
            int rowsAffected = 0;

            try
            {
                rowsAffected = RecipeAccessor.UpdateRecipe(recipe.RecipeID, newName, recipe.Name, newInstructions, recipe.Instructions);

                if (rowsAffected == 1)
                {
                    recipe.Name = newName;
                    recipe.Instructions = newInstructions;
                }
                else
                {
                    throw new ApplicationException("Update returned 0 rows affected.");
                }
            }
            catch (Exception ex)
            {
                throw new ApplicationException("Menu Item change failed.", ex);
            }

            return recipe;
        }

        public bool DeactivateIngredient(Ingredient ingredient)
        {
            bool result = false;

            try
            {
                result = (1 == RecipeAccessor.DeactivateIngredient(ingredient.MenuItemID, ingredient.FoodItemID));
            }
            catch (Exception ex)
            {
                throw new ApplicationException("Ingredient Deactivation failed.", ex);
            }

            return true;
        }

        public bool SaveNewIngredient(Ingredient ingredient)
        {
            var result = false;

            if (ingredient.MenuItemID < 100000 || ingredient.FoodItemID < 100000)
            {
                throw new ApplicationException("You must fill out all the fields.");
            }
            try
            {
                result = (0 != RecipeAccessor.InsertIngredient(ingredient));
            }
            catch (Exception)
            {
                throw;
            }
            return result;
        }
    }
}
