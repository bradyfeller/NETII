﻿using DataAccessLayer;
using DataTransferObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LogicLayer
{
    public class MenuItemManager
    {
        public MenuItem UpdateMenuItem(MenuItem menuItem, string newName, string newDescription)
        {
            int rowsAffected = 0;

            try
            {
                rowsAffected = MenuItemAccessor.UpdateMenuItem(menuItem.MenuItemID, newName, menuItem.Name, newDescription, menuItem.Description);

                if (rowsAffected == 1)
                {
                    menuItem.Name = newName;
                    menuItem.Description = newDescription;
                }
                else
                {
                    throw new ApplicationException("Update returned 0 rows affected.");
                }
            }
            catch (Exception ex)
            {
                throw new ApplicationException("Menu Item change failed.", ex);
            }

            return menuItem;
        }

        public MenuItemDetail RetrieveMenuItemDetail(MenuItem menuItem)
        {
            MenuItemDetail menuItemDetail = null;
            MenuItem menu = null;

            try
            {
                menu = MenuItemAccessor.RetrieveMenuItemByID(menuItem.MenuItemID);
                menuItemDetail = new MenuItemDetail()
                {
                    MenuItem = menuItem
                };
            }
            catch (Exception)
            {
                throw;
            }

            return menuItemDetail;
        }

        public List<MenuItem> RetrieveMenuItemList(bool active = true)
        {
            List<MenuItem> menuItemList = null;

            try
            {
                menuItemList = MenuItemAccessor.RetrieveMenuItemByActive(active);
            }
            catch (Exception)
            {
                throw;
            }

            return menuItemList;
        }

        public bool DeactivateMenuItem(MenuItem menuItem)
        {
            bool result = false;

            try
            {
                result = (1 == MenuItemAccessor.DeactivateMenuItem(menuItem.MenuItemID));
            }
            catch (Exception ex)
            {
                throw new ApplicationException("Menu Item Deactivation failed.", ex);
            }

            return true;
        }

        public bool SaveNewMenuItem(MenuItem menuItem)
        {
            var result = false;

            if (menuItem.Name == "" || menuItem.Description == "")
            {
                throw new ApplicationException("You must fill out all the fields.");
            }
            try
            {
                result = (0 != MenuItemAccessor.InsertMenuItem(menuItem));
            }
            catch (Exception)
            {
                throw;
            }
            return result;
        }
    }
}
