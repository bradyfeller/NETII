﻿using DataTransferObjects;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccessLayer
{
    public static class OrderAccessor
    {
        public static List<Order> RetrieveOrderByActive(bool active = true)
        {
            var orderList = new List<Order>();
            
            var conn = DBConnection.GetDBConnection();
            var cmdText = @"sp_retrieve_order_by_active";
            var cmd = new SqlCommand(cmdText, conn);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue(@"Active", active);

            try
            {
                conn.Open();

                var reader = cmd.ExecuteReader();

                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        var or = new Order()
                        {
                            OrderID = reader.GetInt32(0),
                            EmployeeID = reader.GetString(1),
                            OrderPlaced = reader.GetDateTime(2),
                            OrderStatusID = reader.GetString(3),
                            Active = reader.GetBoolean(4)
                        };
                        orderList.Add(or);
                    }
                }
                else
                {
                    throw new ApplicationException("Data not found.");
                }
            }
            catch (Exception ex)
            {
                throw new ApplicationException("Database access error.", ex);
            }
            finally
            {
                conn.Close();
            }

            return orderList;
        }

        public static List<OrderLine> RetrieveOrderLineByID(int orderID)
        {
            var orderLineList = new List<OrderLine>();
            
            var conn = DBConnection.GetDBConnection();
            var cmdText = @"sp_retrieve_orderline";
            var cmd = new SqlCommand(cmdText, conn);
            cmd.CommandType = CommandType.StoredProcedure;
            
            cmd.Parameters.AddWithValue(@"OrderID", orderID);

            try
            {
                conn.Open();
                
                var reader = cmd.ExecuteReader();

                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        var ol = new OrderLine()
                        {
                            OrderID = reader.GetInt32(0),
                            MenuItemID = reader.GetInt32(1),
                            Active = reader.GetBoolean(2)
                        };
                        orderLineList.Add(ol);
                    }
                }
                else
                {
                    throw new ApplicationException("Data not found.");
                }
            }
            catch (Exception ex)
            {
                throw new ApplicationException("Database access error.", ex);
            }
            finally
            {
                conn.Close();
            }

            return orderLineList;
        }

        public static List<OrderStatus> RetrieveOrderStatus()
        {
            var orderStatusList = new List<OrderStatus>();
            
            var conn = DBConnection.GetDBConnection();
            var cmdText = @"sp_retrieve_order_status_list";
            var cmd = new SqlCommand(cmdText, conn);
            cmd.CommandType = CommandType.StoredProcedure;

            try
            {
                conn.Open();

                var reader = cmd.ExecuteReader();

                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        var os = new OrderStatus()
                        {
                            OrderStatusID = reader.GetString(0)
                        };
                        orderStatusList.Add(os);
                    }
                }
                else
                {
                    throw new ApplicationException("Data not found.");
                }
            }
            catch (Exception ex)
            {
                throw new ApplicationException("Database access error.", ex);
            }
            finally
            {
                conn.Close();
            }

            return orderStatusList;
        }

        public static Order RetrieveOrderByID(int orderID)
        {
            Order order = null;
            
            var conn = DBConnection.GetDBConnection();
            var cmdText = @"sp_retrieve_order_by_id";
            var cmd = new SqlCommand(cmdText, conn);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@OrderID", orderID);
            
            try
            {
                conn.Open();

                var reader = cmd.ExecuteReader();
                
                if (reader.HasRows)
                {
                    reader.Read();

                    var orders = new Order()
                    {
                        OrderID = reader.GetInt32(0),
                        EmployeeID = reader.GetString(1),
                        OrderPlaced = reader.GetDateTime(2),
                        OrderStatusID = reader.GetString(3),
                        Active = reader.GetBoolean(4)
                    };
                }
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                conn.Close();
            }

            return order;
        }
        
        public static int DeactivateOrder(int orderID)
        {
            int result = 0;

            var conn = DBConnection.GetDBConnection();
            var cmdText = @"sp_deactivate_order";
            var cmd = new SqlCommand(cmdText, conn);
            cmd.CommandType = CommandType.StoredProcedure;
            
            cmd.Parameters.AddWithValue("@OrderID", orderID);
            
            try
            {
                conn.Open();
                
                result = cmd.ExecuteNonQuery();

                if (result == 0)
                {
                    throw new ApplicationException("Order deletion failed.");
                }
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                conn.Close();
            }

            return result;
        }

        public static int UpdateOrder(int orderID, string orderStatusID)
        {
            int result = 0;
            
            var conn = DBConnection.GetDBConnection();
            var cmdText = @"sp_update_order";
            var cmd = new SqlCommand(cmdText, conn);
            cmd.CommandType = CommandType.StoredProcedure;
            
            cmd.Parameters.Add("@OrderID", SqlDbType.Int);
            cmd.Parameters.Add("@OrderStatusID", SqlDbType.NVarChar, 50);
            
            cmd.Parameters["@OrderID"].Value = orderID;
            cmd.Parameters["@OrderStatusID"].Value = orderStatusID;
            
            try
            {
                conn.Open();
                
                result = cmd.ExecuteNonQuery();

                if (result == 0)
                {
                    throw new ApplicationException("Order status update failed.");
                }
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                conn.Close();
            }

            return result;
        }

        public static int DeactivateOrderLine(int orderID, int menuItemID)
        {
            int result = 0;
            
            var conn = DBConnection.GetDBConnection();
            var cmdText = @"sp_deactivate_order_line";
            var cmd = new SqlCommand(cmdText, conn);
            cmd.CommandType = CommandType.StoredProcedure;
            
            cmd.Parameters.AddWithValue("@OrderID", orderID);
            cmd.Parameters.AddWithValue("@MenuItemID", menuItemID);
            
            try
            {
                conn.Open();
                
                result = cmd.ExecuteNonQuery();

                if (result == 0)
                {
                    throw new ApplicationException("Order line deletion failed.");
                }
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                conn.Close();
            }

            return result;
        }

        public static int InsertOrder(Order order)
        {
            int newId = 0;

            var conn = DBConnection.GetDBConnection();
            var cmdText = @"sp_insert_order";
            var cmd = new SqlCommand(cmdText, conn);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@EmployeeID", order.EmployeeID);
            cmd.Parameters.AddWithValue("@OrderPlaced", order.OrderPlaced);

            try
            {
                conn.Open();
                decimal id = (decimal)cmd.ExecuteScalar();
                newId = (int)id;
            }
            catch (Exception)
            {
                throw;
            }

            return newId;
        }

        public static int InsertOrderLine(OrderLine orderLine)
        {
            int newId = 0;

            var conn = DBConnection.GetDBConnection();
            var cmdText = @"sp_insert_order_line";
            var cmd = new SqlCommand(cmdText, conn);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@OrderID", orderLine.OrderID);
            cmd.Parameters.AddWithValue("@MenuItemID", orderLine.MenuItemID);

            try
            {
                conn.Open();
                decimal id = (decimal)cmd.ExecuteScalar();
                newId = (int)id;
            }
            catch (Exception)
            {
                throw;
            }

            return newId;
        }
    }
}
