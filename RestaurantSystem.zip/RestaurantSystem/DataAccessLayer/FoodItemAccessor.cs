﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataTransferObjects;
using System.Data.SqlClient;
using System.Data;

namespace DataAccessLayer
{
    public class FoodItemAccessor
    {
        public static int UpdateFoodItem(int foodItemID, string newName, string oldName, string newDescription, string oldDescription)
        {
            int result = 0;
            
            var conn = DBConnection.GetDBConnection();
            var cmdText = @"sp_update_food_item";
            var cmd = new SqlCommand(cmdText, conn);
            cmd.CommandType = CommandType.StoredProcedure;
            
            cmd.Parameters.Add("@FoodItemID", SqlDbType.Int);
            cmd.Parameters.Add("@OldName", SqlDbType.NVarChar, 50);
            cmd.Parameters.Add("@NewName", SqlDbType.NVarChar, 50);
            cmd.Parameters.Add("@OldDescription", SqlDbType.NVarChar, 100);
            cmd.Parameters.Add("@NewDescription", SqlDbType.NVarChar, 100);
            
            cmd.Parameters["@FoodItemID"].Value = foodItemID;
            cmd.Parameters["@OldName"].Value = oldName;
            cmd.Parameters["@NewName"].Value = newName;
            cmd.Parameters["@OldDescription"].Value = oldDescription ?? null;
            cmd.Parameters["@NewDescription"].Value = newDescription;
            
            try
            {
                conn.Open();
                
                result = cmd.ExecuteNonQuery();

                if (result == 0)
                {
                    throw new ApplicationException("Food Item update failed.");
                }
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                conn.Close();
            }

            return result;
        }

        public static List<FoodItem> RetrieveFoodItemByActive(bool active = true)
        {
            var foodItemList = new List<FoodItem>();
            
            var conn = DBConnection.GetDBConnection();
            var cmdText = @"sp_retrieve_fooditem_by_active";
            var cmd = new SqlCommand(cmdText, conn);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue(@"Active", active);

            try
            {
                conn.Open();
                
                var reader = cmd.ExecuteReader();

                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        var fi = new FoodItem()
                        {
                            FoodItemID = reader.GetInt32(0),
                            Name = reader.GetString(1),
                            Description = reader.GetString(2),
                            Active = reader.GetBoolean(3)
                        };
                        foodItemList.Add(fi);
                    }
                }
                else
                {
                    throw new ApplicationException("Data not found.");
                }
            }
            catch (Exception ex)
            {
                throw new ApplicationException("Database access error.", ex);
            }
            finally
            {
                conn.Close();
            }

            return foodItemList;
        }

        public static FoodItem RetrieveFoodItemByID(int foodItemID)
        {
            FoodItem foodItem = null;
            
            var conn = DBConnection.GetDBConnection();
            var cmdText = @"sp_retrieve_fooditem_by_id";
            var cmd = new SqlCommand(cmdText, conn);
            cmd.CommandType = CommandType.StoredProcedure;
            
            cmd.Parameters.AddWithValue("@FoodItemID", foodItemID);
            
            try
            {
                conn.Open();
                
                var reader = cmd.ExecuteReader();
                
                if (reader.HasRows)
                {
                    reader.Read();
                    
                    foodItem = new FoodItem()
                    {
                        FoodItemID = reader.GetInt32(0),
                        Name = reader.GetString(1),
                        Description = reader.GetString(2),
                        Active = reader.GetBoolean(3)
                    };
                }
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                conn.Close();
            }

            return foodItem;
        }

        public static int DeactivateFoodItem(int foodItemID)
        {
            int result = 0;
            
            var conn = DBConnection.GetDBConnection();
            var cmdText = @"sp_deactivate_food_item";
            var cmd = new SqlCommand(cmdText, conn);
            cmd.CommandType = CommandType.StoredProcedure;
            
            cmd.Parameters.AddWithValue("@FoodItemID", foodItemID);
            
            try
            {
                conn.Open();
                
                result = cmd.ExecuteNonQuery();

                if (result == 0)
                {
                    throw new ApplicationException("Food Item deletion failed.");
                }
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                conn.Close();
            }

            return result;
        }

        public static int InsertFoodItem(FoodItem foodItem)
        {
            int newId = 0;

            var conn = DBConnection.GetDBConnection();
            var cmdText = @"sp_insert_food_item";
            var cmd = new SqlCommand(cmdText, conn);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@Name", foodItem.Name);
            cmd.Parameters.AddWithValue("@Description", foodItem.Description);

            try
            {
                conn.Open();
                decimal id = (decimal)cmd.ExecuteScalar();
                newId = (int)id;
            }
            catch (Exception)
            {
                throw;
            }

            return newId;
        }
    }
}
