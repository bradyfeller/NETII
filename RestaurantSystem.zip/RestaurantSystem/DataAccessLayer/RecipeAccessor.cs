﻿using DataTransferObjects;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccessLayer
{
    public class RecipeAccessor
    {
        public static List<Recipe> RetrieveRecipeByActive(bool active = true)
        {
            var recipeList = new List<Recipe>();

            var conn = DBConnection.GetDBConnection();
            var cmdText = @"sp_retrieve_recipe_by_active";
            var cmd = new SqlCommand(cmdText, conn);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue(@"Active", active);

            try
            {
                conn.Open();
                
                var reader = cmd.ExecuteReader();

                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        var re = new Recipe()
                        {
                            RecipeID = reader.GetInt32(0),
                            MenuItemID = reader.GetInt32(1),
                            Name = reader.GetString(2),
                            Instructions = reader.GetString(3),
                            Active = reader.GetBoolean(4)
                        };
                        recipeList.Add(re);
                    }
                }
                else
                {
                    throw new ApplicationException("Data not found.");
                }
            }
            catch (Exception ex)
            {
                throw new ApplicationException("Database access error.", ex);
            }
            finally
            {
                conn.Close();
            }

            return recipeList;
        }

        public static Recipe RetrieveRecipeByID(int recipeID)
        {
            Recipe recipe = null;

            var conn = DBConnection.GetDBConnection();
            var cmdText = @"sp_retrieve_recipe_by_id";
            var cmd = new SqlCommand(cmdText, conn);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@RecipeID", recipeID);
            try
            {
                conn.Open();

                var reader = cmd.ExecuteReader();
                
                if (reader.HasRows)
                {
                    reader.Read();
                    
                    var recipes = new Recipe()
                    {
                        RecipeID = reader.GetInt32(0),
                        MenuItemID = reader.GetInt32(1),
                        Name = reader.GetString(2),
                        Instructions = reader.GetString(3),
                        Active = reader.GetBoolean(4)
                    };
                }
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                conn.Close();
            }

            return recipe;
        }

        public static List<Ingredient> RetrieveIngredientByID(int menuItemID)
        {
            var ingredientList = new List<Ingredient>();
            
            var conn = DBConnection.GetDBConnection();
            var cmdText = @"sp_retrieve_ingredient";
            var cmd = new SqlCommand(cmdText, conn);
            cmd.CommandType = CommandType.StoredProcedure;            
            cmd.Parameters.AddWithValue(@"MenuItemID", menuItemID);

            try
            {
                conn.Open();
                
                var reader = cmd.ExecuteReader();

                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        var ig = new Ingredient()
                        {
                            MenuItemID = reader.GetInt32(0),
                            FoodItemID = reader.GetInt32(1),
                            Quantity = reader.GetInt32(2),
                            Unit = reader.GetString(3),
                            Active = reader.GetBoolean(4)
                        };
                        ingredientList.Add(ig);
                    }
                }
                else
                {
                    throw new ApplicationException("Data not found.");
                }
            }
            catch (Exception ex)
            {
                throw new ApplicationException("Database access error.", ex);
            }
            finally
            {
                conn.Close();
            }

            return ingredientList;
        }

        public static int DeactivateRecipe(int recipeID)
        {
            int result = 0;
            
            var conn = DBConnection.GetDBConnection();
            var cmdText = @"sp_deactivate_recipe";
            var cmd = new SqlCommand(cmdText, conn);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@RecipeID", recipeID);
            
            try
            {
                conn.Open();
                
                result = cmd.ExecuteNonQuery();

                if (result == 0)
                {
                    throw new ApplicationException("Food Item deletion failed.");
                }
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                conn.Close();
            }

            return result;
        }

        public static int InsertRecipe(Recipe recipe)
        {
            int newId = 0;

            var conn = DBConnection.GetDBConnection();
            var cmdText = @"sp_insert_recipe";
            var cmd = new SqlCommand(cmdText, conn);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@MenuItemID", recipe.MenuItemID);
            cmd.Parameters.AddWithValue("@Name", recipe.Name);
            cmd.Parameters.AddWithValue("@Instructions", recipe.Instructions);

            try
            {
                conn.Open();
                decimal id = (decimal)cmd.ExecuteScalar();
                newId = (int)id;
            }
            catch (Exception)
            {
                throw;
            }

            return newId;
        }

        public static int UpdateRecipe(int recipeID, string newName, string oldName, string newInstructions, string oldInstructions)
        {
            int result = 0;
            
            var conn = DBConnection.GetDBConnection();
            var cmdText = @"sp_update_recipe";
            var cmd = new SqlCommand(cmdText, conn);
            cmd.CommandType = CommandType.StoredProcedure;
            
            cmd.Parameters.Add("@RecipeID", SqlDbType.Int);
            cmd.Parameters.Add("@OldName", SqlDbType.NVarChar, 50);
            cmd.Parameters.Add("@NewName", SqlDbType.NVarChar, 50);
            cmd.Parameters.Add("@OldInstructions", SqlDbType.NVarChar, 250);
            cmd.Parameters.Add("@NewInstructions", SqlDbType.NVarChar, 250);
            
            cmd.Parameters["@RecipeID"].Value = recipeID;
            cmd.Parameters["@OldName"].Value = oldName;
            cmd.Parameters["@NewName"].Value = newName;
            cmd.Parameters["@OldInstructions"].Value = oldInstructions;
            cmd.Parameters["@NewInstructions"].Value = newInstructions;
            
            try
            {
                conn.Open();

                result = cmd.ExecuteNonQuery();

                if (result == 0)
                {
                    throw new ApplicationException("Recipe update failed.");
                }
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                conn.Close();
            }

            return result;
        }

        public static int DeactivateIngredient(int menuItemID, int foodItemID)
        {
            int result = 0;
            
            var conn = DBConnection.GetDBConnection();
            var cmdText = @"sp_deactivate_ingredient";
            var cmd = new SqlCommand(cmdText, conn);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@MenuItemID", menuItemID);
            cmd.Parameters.AddWithValue("@FoodItemID", foodItemID);
            
            try
            {
                conn.Open();
                
                result = cmd.ExecuteNonQuery();

                if (result == 0)
                {
                    throw new ApplicationException("Ingredient deletion failed.");
                }
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                conn.Close();
            }

            return result;
        }

        public static int InsertIngredient(Ingredient ingredient)
        {
            int newId = 0;

            var conn = DBConnection.GetDBConnection();
            var cmdText = @"sp_insert_ingredient";
            var cmd = new SqlCommand(cmdText, conn);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@MenuItemID", ingredient.MenuItemID);
            cmd.Parameters.AddWithValue("@FoodItemID", ingredient.FoodItemID);
            cmd.Parameters.AddWithValue("@Quantity", ingredient.Quantity);
            cmd.Parameters.AddWithValue("@Unit", ingredient.Unit);

            try
            {
                conn.Open();
                decimal id = (decimal)cmd.ExecuteScalar();
                newId = (int)id;
            }
            catch (Exception)
            {
                throw;
            }

            return newId;
        }
    }
}
