﻿using DataTransferObjects;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccessLayer
{
    public static class EquipmentAccessor
    {
        public static List<Equipment> RetrieveEquipmentByActive(bool active = true)
        {
            var equipmentList = new List<Equipment>();

            // connection
            var conn = DBConnection.GetDBConnection();

            // command text
            var cmdText = @"sp_select_equipment_by_active";

            // command
            var cmd = new SqlCommand(cmdText, conn);

            // command type
            cmd.CommandType = CommandType.StoredProcedure;

            // parameters and values
            cmd.Parameters.AddWithValue("@Active", active);

            // try-catch
            try
            {
                // open connection
                conn.Open();
                // execute command
                var reader = cmd.ExecuteReader();

                // rows ?
                if (reader.HasRows)
                {
                    // process the reader
                    while (reader.Read())
                    {
                        var eq = new Equipment()
                        {



                            /*  [EquipmentID],[Name],[Description],[StatusID],
                                [EquipmentModelID], [InspectionListID],
                                [PrepListID],[Active] */
                            EquipmentID = reader.GetInt32(0),
                            Name = reader.GetString(1),
                            Description = reader.GetString(2),
                            StatusID = reader.GetString(3),
                            EquipmentModelID = reader.GetInt32(4),
                            InspectionListID = reader.IsDBNull(5) ? null : (int?)reader.GetInt32(5), // we'll return to this
                            PrepListID = reader.IsDBNull(6) ? null : (int?)reader.GetInt32(6), // we'll return to this, too
                            Active = reader.GetBoolean(7)
                        };
                        equipmentList.Add(eq);
                    }
                }
                else // no rows?
                {
                    throw new ApplicationException("Data not found.");
                }
            }
            catch (Exception ex)
            {
                throw new ApplicationException("Database access error.", ex);
            }
            finally
            {
                conn.Close();
            }
            return equipmentList;
        }

        public static List<EquipmentModel> RetrieveEquimentModelByActive(bool active = true)
        {
            var equipmentModelList = new List<EquipmentModel>();

            // connection
            var conn = DBConnection.GetDBConnection();

            // command text
            var cmdText = @"sp_select_equipmentmodel_by_active";

            // command
            var cmd = new SqlCommand(cmdText, conn);

            // command type
            cmd.CommandType = CommandType.StoredProcedure;

            // parameters and values
            cmd.Parameters.AddWithValue("@Active", active);

            // try-catch
            try
            {
                // open connection
                conn.Open();
                // execute command
                var reader = cmd.ExecuteReader();

                // rows ?
                if (reader.HasRows)
                {
                    // process the reader
                    while (reader.Read())
                    {
                        var em = new EquipmentModel()
                        {
                            /* [EquipmentModelID], [Name], [Description], [Active]
                            */
                            EquipmentModelID = reader.GetInt32(0),
                            Name = reader.GetString(1),
                            Description = reader.GetString(2),
                            Active = reader.GetBoolean(3)
                        };
                        equipmentModelList.Add(em);
                    }
                }
                else // no rows?
                {
                    throw new ApplicationException("Data not found.");
                }
            }
            catch (Exception ex)
            {
                throw new ApplicationException("Database access error.", ex);
            }
            finally
            {
                conn.Close();
            }
            return equipmentModelList;
        }

        public static List<InspectionList> RetrieveInspectionListByActive(bool active = true)
        {
            var inspectionList = new List<InspectionList>();

            // connection
            var conn = DBConnection.GetDBConnection();

            // command text
            var cmdText = @"sp_select_inspectionlist_by_active";

            // command
            var cmd = new SqlCommand(cmdText, conn);

            // command type
            cmd.CommandType = CommandType.StoredProcedure;

            // parameters and values
            cmd.Parameters.AddWithValue("@Active", active);

            // try-catch
            try
            {
                // open connection
                conn.Open();
                // execute command
                var reader = cmd.ExecuteReader();

                // rows ?
                if (reader.HasRows)
                {
                    // process the reader
                    while (reader.Read())
                    {
                        var il = new InspectionList()
                        {
                            /* [EquipmentModelID], [Name], [Description], [Active]
                            */
                            InspectionListID = reader.GetInt32(0),
                            Name = reader.GetString(1),
                            Description = reader.GetString(2),
                            Active = reader.GetBoolean(3)
                        };
                        inspectionList.Add(il);
                    }
                }
                else // no rows?
                {
                    throw new ApplicationException("Data not found.");
                }
            }
            catch (Exception ex)
            {
                throw new ApplicationException("Database access error.", ex);
            }
            finally
            {
                conn.Close();
            }
            return inspectionList;
        }

        public static List<PrepList> RetrievePrepListByActive(bool active = true)
        {
            var prepList = new List<PrepList>();

            // connection
            var conn = DBConnection.GetDBConnection();

            // command text
            var cmdText = @"sp_select_preplist_by_active";

            // command
            var cmd = new SqlCommand(cmdText, conn);

            // command type
            cmd.CommandType = CommandType.StoredProcedure;

            // parameters and values
            cmd.Parameters.AddWithValue("@Active", active);

            // try-catch
            try
            {
                // open connection
                conn.Open();
                // execute command
                var reader = cmd.ExecuteReader();

                // rows ?
                if (reader.HasRows)
                {
                    // process the reader
                    while (reader.Read())
                    {
                        var il = new PrepList()
                        {
                            /* [EquipmentModelID], [Name], [Description], [Active]
                            */
                            PrepListID = reader.GetInt32(0),
                            Name = reader.GetString(1),
                            Description = reader.GetString(2),
                            Active = reader.GetBoolean(3)
                        };
                        prepList.Add(il);
                    }
                }
                else // no rows?
                {
                    throw new ApplicationException("Data not found.");
                }
            }
            catch (Exception ex)
            {
                throw new ApplicationException("Database access error.", ex);
            }
            finally
            {
                conn.Close();
            }
            return prepList;
        }

        public static List<Status> RetrieveStatusList()
        {
            var statusList = new List<Status>();

            // connection
            var conn = DBConnection.GetDBConnection();

            // command text
            var cmdText = @"sp_select_status_list";

            // command
            var cmd = new SqlCommand(cmdText, conn);

            // command type
            cmd.CommandType = CommandType.StoredProcedure;

            // no parameters

            // try-catch
            try
            {
                // open connection
                conn.Open();
                // execute command
                var reader = cmd.ExecuteReader();

                // rows ?
                if (reader.HasRows)
                {
                    // process the reader
                    while (reader.Read())
                    {
                        var st = new Status()
                        {
                            /* [StatusID] */
                            StatusID = reader.GetString(0)
                        };
                        statusList.Add(st);
                    }
                }
                else // no rows?
                {
                    throw new ApplicationException("Data not found.");
                }
            }
            catch (Exception ex)
            {
                throw new ApplicationException("Database access error.", ex);
            }
            finally
            {
                conn.Close();
            }
            return statusList;
        }

        public static EquipmentModel RetrieveEquipmentModelByID(int equipmentModelID)
        {
            EquipmentModel equipmentModel = null;

            // connection
            var conn = DBConnection.GetDBConnection();

            // command text
            var cmdText = @"sp_select_equipmentmodel_by_id";

            // command
            var cmd = new SqlCommand(cmdText, conn);

            // command type
            cmd.CommandType = CommandType.StoredProcedure;

            // parameters and values
            cmd.Parameters.AddWithValue("@EquipmentModelID", equipmentModelID);

            // try-catch
            try
            {
                // open the connection
                conn.Open();

                // execute the command
                var reader = cmd.ExecuteReader();

                if(reader.HasRows)
                {
                    reader.Read();

                    equipmentModel = new EquipmentModel()
                    {
                        EquipmentModelID = reader.GetInt32(0),
                        Name = reader.GetString(1),
                        Description = reader.GetString(2),
                        Active = reader.GetBoolean(3)
                    };
                }
                else
                {
                    throw new ApplicationException("Record not found.");
                }
            }
            catch (Exception ex)
            {
                throw new ApplicationException("Data access error.", ex);
            }
            finally
            {
                conn.Close();
            }

            return equipmentModel;
        }

        public static InspectionList RetrieveInspectionListByID(int inspectionListID)
        {
            InspectionList inspectionList = null;

            // connection
            var conn = DBConnection.GetDBConnection();

            // command text
            var cmdText = @"sp_select_inspectionlist_by_id";

            // command
            var cmd = new SqlCommand(cmdText, conn);

            // command type
            cmd.CommandType = CommandType.StoredProcedure;

            // parameters and values
            cmd.Parameters.AddWithValue("@InspectionlistID", inspectionListID);

            // try-catch
            try
            {
                // open the connection
                conn.Open();

                // execute the command
                var reader = cmd.ExecuteReader();

                if (reader.HasRows)
                {
                    reader.Read();

                    inspectionList = new InspectionList()
                    {
                        InspectionListID = reader.GetInt32(0),
                        Name = reader.GetString(1),
                        Description = reader.GetString(2),
                        Active = reader.GetBoolean(3)
                    };
                }
                else
                {
                    throw new ApplicationException("Record not found.");
                }
            }
            catch (Exception ex)
            {
                throw new ApplicationException("Data access error.", ex);
            }
            finally
            {
                conn.Close();
            }

            return inspectionList;
        }

        public static PrepList RetrievePrepListByID(int preplistID)
        {
            PrepList prepList = null;

            // connection
            var conn = DBConnection.GetDBConnection();

            // command text
            var cmdText = @"sp_select_preplist_by_id";

            // command
            var cmd = new SqlCommand(cmdText, conn);

            // command type
            cmd.CommandType = CommandType.StoredProcedure;

            // parameters and values
            cmd.Parameters.AddWithValue("@PreplistID", preplistID);

            // try-catch
            try
            {
                // open the connection
                conn.Open();

                // execute the command
                var reader = cmd.ExecuteReader();

                if (reader.HasRows)
                {
                    reader.Read();

                    prepList = new PrepList()
                    {
                        PrepListID = reader.GetInt32(0),
                        Name = reader.GetString(1),
                        Description = reader.GetString(2),
                        Active = reader.GetBoolean(3)
                    };
                }
                else
                {
                    throw new ApplicationException("Record not found.");
                }
            }
            catch (Exception ex)
            {
                throw new ApplicationException("Data access error.", ex);
            }
            finally
            {
                conn.Close();
            }

            return prepList;
        }
    }
}
